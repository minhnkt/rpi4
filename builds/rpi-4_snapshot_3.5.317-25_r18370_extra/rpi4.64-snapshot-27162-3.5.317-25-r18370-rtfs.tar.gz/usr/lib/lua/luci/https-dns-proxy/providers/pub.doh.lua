return{
	name = "DNSPod-cn-Public-DNS",
	label = _("DNSPod.cn Public DNS"),
	resolver_url = "https://doh.pub/dns-query",
	bootstrap_dns = "119.29.29.29,119.28.28.28"
}
