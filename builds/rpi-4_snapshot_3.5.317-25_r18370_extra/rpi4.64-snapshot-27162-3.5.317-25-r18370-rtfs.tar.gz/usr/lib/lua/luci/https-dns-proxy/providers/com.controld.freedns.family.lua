return {
	name = "ControlD-Family",
	label = _("ControlD (Family)"),
	resolver_url = "https://freedns.controld.com/family",
	bootstrap_dns = "76.76.2.4,2606:1a40::4",
	help_link = "https://kb.controld.com/tutorials",
	help_link_text = "ControlD"
}