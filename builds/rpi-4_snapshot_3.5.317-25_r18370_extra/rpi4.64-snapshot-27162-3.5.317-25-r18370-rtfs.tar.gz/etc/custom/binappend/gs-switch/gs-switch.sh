#!/bin/sh

#git clone https://github.com/Tristan79/ProSafeLinux








MNAME="gs-switch.sh"



echL() {

	local MSG="${1}"; shift

    	case "${1}" in
		verbose) if [ ! -z "$VERBOSE" ]; then echo "V:: $MNAME> $MSG"; fi; ;;
        	debug) if [ ! -z "$DEBUG" ]; then echo "D:: $MNAME> $MSG"; fi; ;;
		*|msg) echo "::: $MNAME> $MSG"; ;; #msghackedintoheretemp
    	esac

    	case "${1}" in
    		log) logger -t "$MNAME" "::: $MNAME> $MSG"; return 0; ;;
	esac

}





















installOPKGs() {

	opkg update 1>/dev/null 2>/dev/null || return 1
	opkg install ${*} 1>/dev/null 2>/dev/null || return 1

}






prereqCHECKA() {

	local FN="prereqCHECKA"
	if [ -z "$MNAME" ]; then echL "MNAME@ff empty"; sleep 3; MNAME="unknown"; fi
	local REQff="/root/.${MNAME}.prereq"
	
	local pINSTALL pINSTOK pkgISSUES ALLPACKAGES=${*}

	if [ -z "$ALLPACKAGES" ]; then return 0; fi
	if ! grep -xFq "${ALLPACKAGES}" "$REQff" 2>/dev/null; then
		rm "$REQff" 2>/dev/null
	elif [ -f "$REQff" ]; then
		[ -n "$DEBUG" ] && echL "$FN> checked already: $REQff" msg; return 0
	else
		[ -n "$DEBUG" ] && echL "$FN> NOT checked already: $REQff" msg
	fi
	for chkPKG in ${ALLPACKAGES}; do
		if [ "$(opkg status ${chkPKG} | wc -l)" -eq 0 ]; then
			pINSTALL="${pINSTALL} ${chkPKG}"; [ -n "$DEBUG" ] && echL "$FN> ${chkPKG} [installqueue]" msg
		else
			pINSTOK="${pINSTOK} ${chkPKG}"; [ -n "$DEBUG" ] && echL "${chkPKG} [onsys]" msg
		fi
	done


	if [ -z "$pINSTALL" ]; then
		echL "Zero packages to add... $pINSTOK" verbose; echo "${ALLPACKAGES}" > "$REQff"; return 0
		#@@@notecalledmulti>appendandgrep
	fi


	PKGISSUES="${pINSTALL}"
	if [ ! -z "$PKGISSUES" ]; then
		#echo "pre-requisites-missing: $PKGISSUES" && return 1
		echL "installing: $PKGISSUES"
		installOPKGs $PKGISSUES || return 1
		return 0
	else
		return 0; #echL "$FN> adding: ${pINSTALL}" msg
	fi

}










parseallparams() {

	#if [ "$#" -eq 0 ]; then MSGEXTRA="noparams given"; printusage; return 0; fi #[ -n "$DEBUG" ] && echo "noparams given"
	#if [ "$#" -eq 0 ]; then MSGEXTRA="noparams given"; printusage; exit 0; fi #[ -n "$DEBUG" ] && echo "noparams given"

	while [ "$#" -gt 0 ]; do
		case "$1" in
		-h|--help|help) printusage && exit 0; ;;
		-D|debug) DEBUG=1; RUNOPTS="${RUNOPTS} debug"; shift; ;;
		-V|verbose) VERBOSE=1; shift; ;;
		-f|force) FORCE=1; shift 1; ;;
		-Q|quick) QUICK=1; shift ;;
		#####################################################
		


		-I) IFACE=${2}; shift 2; ;;	
		-T) TIMEOUT=${2}; shift 2; ;;	
		

		pslcmdhelp) DOCMD="pslcmdhelp"; shift 1; ;;	
		switchinfo) DOCMD="switchinfo"; shift 1; ;;	









		fetch)
			DOFETCH=1; shift

			if [ ! -z "${1}" ] && [ "$(echo ${1} | wc -c)" -eq 41 ]; then
				EEPROM_GIT_HASH=${1}
				shift 1
			fi
		;;



		


		*"dev"*)
			#@@@validate ./diskgetit.sh /dev/mmcblk0 1onlynotall
			DISK="${1}"
			shift 1
		;;
		

	*) echo "unknown param: $1"; shift; ;;
		#*) MSGEXTRA="unknown param: $1"; printusage; exit 1; ;;
		esac
	done
}
#label|partuuid) DUMPLINES="${DUMPLINES} $1"; shift 1;;













printusage() {
cat <<TTT
	${MSGEXTRA}
	$0
		-T <timeout>


		-I <iface>


		switchinfo
		pslcmdhelp



	NOTE: ################################ /root/wrt.ini unless provided on cmdline
	GSSWITCH_IFACE="br-lan"
	GSSWITCH_MAC="9C:C9:EB:XX:XX:XX"
	GSSWITCH_PASS="YOURPASSWORD"

TTT
}





#set -x


ALLPARAMS=${*}
parseallparams $ALLPARAMS


if [ ! -z "$DEBUG" ]; then VERBOSE=1; fi #@echL-logic








eval `grep '^GSSWITCH_MAC=' /root/wrt.ini 2>/dev/null`
eval `grep '^GSSWITCH_IFACE=' /root/wrt.ini 2>/dev/null`
eval `grep '^GSSWITCH_PASS=' /root/wrt.ini 2>/dev/null`


if [ ! -z "$GSSWITCH_MAC" ]; then MAC="${MAC:-"$GSSWITCH_MAC"}"; fi
if [ ! -z "$GSSWITCH_IFACE" ]; then IFACE="${IFACE:-"$GSSWITCH_IFACE"}"; fi
if [ ! -z "$GSSWITCH_PASS" ]; then PASS="${PASS:-"$GSSWITCH_PASS"}"; fi





if [ -z "$MAC" ]; then ISSUES="${ISSUES} MAC[z]"; fi
if [ -z "$IFACE" ]; then ISSUES="${ISSUES} IFACE[z]"; fi
if [ -z "$PASS" ]; then ISSUES="${ISSUES} PASS[z]"; fi
#if [ ! -z "$ISSUES" ]; then MSGEXTRA="ISSUES: $ISSUES"; printusage; exit 0; fi





#set -x


if [ -f psl-cmd.py ]; then
	BINAPPEND="$(realpath $(pwd))"
elif [ -d /etc/custom/binappend/gs-switch ]; then
	BINAPPEND="/etc/custom/binappend/gs-switch"
fi
if [ ! -z "$BINAPPEND" ]; then export PATH="$BINAPPEND:${PATH}"; fi #echL "export PATH=\"$BINAPPEND:${PATH}\"" debug


if [ -z $(command -v psl-cli.py) ]; then ISSUES="${ISSUES} psl-cli.py[nope]"; fi #!!!!!!$(command -v psl-cmd.py


if [ ! -z "$ISSUES" ]; then MSGEXTRA="ISSUES: $ISSUES"; printusage; exit 0; fi



PSLCMD="$(command -v psl-cli.py)" #!!!not(default) psl-cmd.py!!!







#####################################COMPATVARS I.E. USED BY ORIGINAL COMMANDS for QUICK TESTS
INTERFACE="${IFACE}"
PW="${PASS}"








PACKAGES="python3 python3-netifaces"
if ! prereqCHECKA ${PACKAGES}; then exit 0; fi 



#PACKAGES="python3 python3-netifaces" #python3-base
#python3-pip python-pip-conf
#python3-asyncio
#python3-cgi
#python3-cgitb
#python3-codecs
#python3-ctypes
#python3-dbm
#python3-decimal
#python3-distutils
#python3-email
#python3-gdbm
#python3-light
#python3-logging
#python3-lzma
#python3-multiprocessing
#python3-ncurses
#python3-openssl
#python3-paho-mqtt
#python3-pkg-resources
#python3-pydoc
#python3-setuptools
#python3-sqlite3
#python3-unittest
#python3-urllib
#python3-xml











TIMEOUT="${TIMEOUT:-"3"}"; T="--timeout ${TIMEOUT}"

THISPASS="--passwd $PASS"
FULLFACE="--interface $IFACE"



echL "PATH=\"${PATH}\"" verbose
echL "TIMEOUT=\"${TIMEOUT}\"" verbose
echL "PSLCMD=\"${PSLCMD}\"" verbose




















testpslsh() {
######################### test-psl.sh #!/bin/sh
set -x

NAME=name$(date +%s)
./psl-cli.py --interface $INTERFACE discover
./psl-cli.py --interface $INTERFACE query --mac $MAC all
./psl-cli.py --interface $INTERFACE set --mac $MAC --passwd $PW --name $NAME
./psl-cli.py --interface $INTERFACE discover |grep $NAME
if [ "$?" != "0" ] ; then
    echo "Name not set!"
fi
./psl-cli.py --interface $INTERFACE set --mac $MAC --passwd $PW --dhcp off --ip 192.168.11.117 --netmask 255.255.255.0 --gateway 192.168.11.2
./psl-cli.py --interface $INTERFACE query --mac $MAC dhcp ip gateway netmask
./psl-cli.py --interface $INTERFACE set --mac $MAC --passwd $PW --dhcp off --ip 192.168.11.116 --netmask 255.255.255.0 --gateway 192.168.11.1
./psl-cli.py --interface $INTERFACE query --mac $MAC dhcp ip gateway netmask
./psl-cli.py --interface $INTERFACE set --mac $MAC --passwd $PW --dhcp on
./psl-cli.py --interface $INTERFACE query --mac $MAC dhcp ip gateway netmask

exit 0
}








cleanit() {
	tr -s '\t' ' ' | cut -d' ' -f2

}



combocommand() {

	case "${1}" in
		ipinfo)
		#echo "${PSLCMD} ${DEBUG} $T $FULLFACE query --mac $MAC ip"
		#exit 0

		DEV_IPline="$(${PSLCMD} ${DEBUG} $T $FULLFACE query --mac $MAC ip)"
		DEV_MASKline="$(${PSLCMD} ${DEBUG} $T $FULLFACE query --mac $MAC netmask)"
		DEV_GATEWAYline="$(${PSLCMD} ${DEBUG} $T $FULLFACE query --mac $MAC gateway)"
		DEV_DHCPline="$(${PSLCMD} ${DEBUG} $T $FULLFACE query --mac $MAC dhcp)"

		DEV_IP="$(echo $DEV_IPline | cleanit)"
		DEV_MASK="$(echo $DEV_MASKline | cleanit)"
		DEV_GATEWAY="$(echo $DEV_GATEWAYline | cleanit)"
		DEV_DHCP="$(echo $DEV_DHCPline | cleanit)"


		echo "ip:$DEV_IP mask:$DEV_MASK gw:${DEV_GATEWAY} dhcp:$DEV_DHCP"

		;;
	esac

}




#${PSLCMD} --interface $INTERFACE query --mac $MAC dhcp ip gateway netmask | cleanit
#exit 0


#${PSLCMD} --interface $INTERFACE query --mac $MAC dhcp ip gateway netmask | cleanit
#exit 0








#########debugset
#./psl-cli.py --interface br-lan set --mac 9C:C9:EB:D8:0F:3D --passwd "${PW}" --dhcp on
#exit 0
#./psl-cli.py --interface br-lan set --mac 9C:C9:EB:D8:0F:3D --passwd "${PW}" --dhcp on






if [ -z "$DOCMD" ]; then
	MSGEXTRA="$0 [switchinfo|x|etc]]"; printusage; exit 0
fi

case "$DOCMD" in


	pslcmdhelp) #help|--help|-h)
		echo "$PSLCMD --help 2>&1"
		$PSLCMD --help 2>&1
	;;



	switchinfo)

		
		combocommand "ipinfo"


		exit 0
	;;



	b)
		$PSLCMD --help 2>&1
	;;
	v)
		$PSLCMD --help 2>&1
	;;
	g)
		$PSLCMD --help 2>&1
	;;
	t)
		$PSLCMD --help 2>&1
	;;











	*)
		echo "nodetup: $DOCMD"
	;;

esac



exit 0




#${PSLCMD} ${DEBUG} $T $FULLFACE query --mac $MAC vlan802_id













#MAC=""; IFACE="br-lan"; PASS=""' T="--timeout 3" #T="--timeout 10" T="--timeout 10"


















#DEBUG="--debug"
#set -x






















exit 0


#ASROOT #opkg install python3-netifaces
#a few print >( ... )< fixed (5ish in cli.py and 1or2ininclude)
#br-lan!eth0!
##########################################################
#python3-netifaces #TRISTANVERSION #pylint3
##########################################################
#./psl_class.py:    RECPORT = 63321
#./psl_class.py:    SENDPORT = 63322
##########################################################
#cat DISCOVERTXT.txt | grep 0000 | grep -v 'fe80'  | grep -v google 















#THEBASEBITS




