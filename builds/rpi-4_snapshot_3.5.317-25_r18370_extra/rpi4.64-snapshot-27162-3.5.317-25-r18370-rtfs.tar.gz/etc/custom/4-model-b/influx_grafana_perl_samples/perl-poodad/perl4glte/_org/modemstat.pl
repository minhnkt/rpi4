use strict;
use Device::SerialPort;
use LWP::UserAgent;
use HTTP::Request::Common qw(POST GET DELETE);

#Current Time:  6422             Temperature: 23
#Reset Counter: 1                Mode:        ONLINE
#System mode:   LTE              PS state:    Attached
#LTE band:      B5               LTE bw:      5 MHz
#LTE Rx chan:   2475             LTE Tx chan: 20475
#LTE SSC1 state:INACTIVE         LTE SSC1 band: B1
#LTE SSC1 bw  : 15 MHz           LTE SSC1 chan: 675
#LTE SSC2 state:INACTIVE         LTE SSC2 band: B29
#LTE SSC2 bw  : 5 MHz            LTE SSC2 chan: 9840
#LTE SSC3 state:NOT ASSIGNED
#LTE SSC4 state:NOT ASSIGNED
#EMM state:     Registered       Normal Service
#RRC state:     RRC Connected
#IMS reg state: No Srv
#
#PCC RxM RSSI:  -80              PCC RxM RSRP:  -108
#PCC RxD RSSI:  -80              PCC RxD RSRP:  -108
#SCC1 RxM RSSI: -63              SCC1 RxM RSRP: -95
#SCC1 RxD RSSI: -64              SCC1 RxD RSRP: -96
#SCC2 RxM RSSI: -102             SCC2 RxM RSRP: -134
#SCC2 RxD RSSI: -102             SCC2 RxD RSRP: -134
#Tx Power:      22               TAC:         2088 (8328)
#RSRQ (dB):     -16.1            Cell ID:     02587901 (39352577)
#SINR (dB):     -4.0
#
#
#OK

my $port=Device::SerialPort->new("/dev/ttyUSB2");

my $STALL_DEFAULT=3; # how many seconds to wait for new input

my $timeout=$STALL_DEFAULT;

$port->read_char_time(0);     # don't wait for each character
$port->read_const_time(1000); # 1 second per unfulfilled "read" call
$port->datatype('raw');
$port->write("\r\rAT\r");
sleep(1);
$port->read(100);

$port->write("AT!GSTATUS?\r");

#sleep(1);

my $chars=0;
my $buffer="";
while ($timeout > 0) {
    my ($count, $saw) = $port->read(255); # will read _up to_ 255 chars
    if ($count > 0) {
            $chars += $count;
            $buffer .= $saw;
    }
    else {
            $timeout--;
    }
    last if $buffer =~ /OK\r\n$/;
}

print "timeout: $timeout Buffer:\n";
print "$buffer\n";


my @tmp = split /\r\n/, $buffer;

my %pairs;

foreach my $l (@tmp) {
    chomp $l;
    next if $l =~ /GSTATUS/;
    next unless $l =~ /\:/;

    $l =~ s/ *\: +/:/g;               # condense ':' followed by spaces down to just ':'

    while( $l =~ /\S \S/ ) {
        $l =~ s/(\S) (\S)/$1_$2/g;  # replace X X with X_X
    }
    
    my @tmp1 = split /\s+/, $l;     # split line on spaces
    
    while( my $x = shift @tmp1 ) {
        my ($k, $v ) = split /\:/, $x;
        $pairs{$k} = $v;
        next unless $tmp1[0];
        next if $tmp1[0] =~ /\:/;		# next token is a key:value pair
        $pairs{$k} = $pairs{$k} . '_' . shift @tmp1;
    }

}

foreach my $key ( sort keys %pairs ) {
    print "key: $key  value: $pairs{$key}\n";
}

my $hostname = `uname -n`;
chomp $hostname;

my $line = "modem,host=$hostname ";
$line .= "emmstate=\"$pairs{EMM_state}\"";
$line .= ",imsregstate=\"$pairs{IMS_reg_state}\"";
$line .= ",lteband=\"$pairs{LTE_band}\"";
$line .= ",pcc_rxd_rsrp=$pairs{PCC_RxD_RSRP}" . 'i';
$line .= ",pcc_rxd_rssi=$pairs{PCC_RxD_RSSI}" . 'i';
$line .= ",pcc_rxm_rsrp=$pairs{PCC_RxM_RSRP}" . 'i';
$line .= ",pcc_rxm_rssi=$pairs{PCC_RxM_RSSI}" . 'i';
$line .= ",pcc_rxd_rsrp=$pairs{PCC_RxD_RSRP}" . 'i';
$line .= ",rsrq=$pairs{'RSRQ_(dB)'}";
$line .= ",sinr=$pairs{'SINR_(dB)'}";
$line .= ",temp=$pairs{Temperature}" . 'i';

my @meas;
push @meas, $line;


print join "\n", @meas;
print "\n";

WriteInflux("192.168.1.12", "host", @meas);

exit 0;

sub WriteInflux {
    my $server = shift;
    my $db = shift;
    my @dat = @_;
    
    my $body = join "\n", @dat;
    
    my $url = "http://$server:8086/write?db=$db";
    
    my $ua = LWP::UserAgent->new;
    my $req = (POST $url, Content=>$body);
    my $res = $ua->request($req);
    
    print "code: ", $res->code, "\n";
    print "content: ", $res->content, "\n";
    
}



