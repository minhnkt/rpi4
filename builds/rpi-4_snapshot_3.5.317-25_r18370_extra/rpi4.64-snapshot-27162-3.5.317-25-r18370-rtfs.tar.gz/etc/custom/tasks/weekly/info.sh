#!/bin/sh
#uname -a
#uptime




dumptheinfo() {

uname -a
uptime
echo "conntrack_cnt:$(conntrack -L 2>/dev/null | wc -l)"

}


dumptheinfo



echo "################ tasks.sh>daily>dumptheinfo" >> /tmp/infolog
dumptheinfo >> /tmp/infolog













