#!/bin/sh


#################################################### BASED-ON
# BCP38 filtering implementation for CeroWrt.
#
# This program is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License as published by the Free Software
# Foundation; either version 3 of the License, or (at your option) any later
# version.
#
# Author: Toke Høiland-Jørgensen <toke@toke.dk>
##############################################################









###################################################################3
ecmd="echo "; i=$(basename $0)
if [ -x /etc/custom/custfunc.sh ]; then . /etc/custom/custfunc.sh; ecmd="echm ${i} "; fi

#sleep ${RCSLEEP:-0}
#[ -n "$DEBUG" ]
###################################################################3













STOP=$1
IPSET_NAME=rfc1918-ipv4
SNAME=RFC1918
IPTABLES_CHAIN=$SNAME


. /lib/functions.sh




#MOVEDOWNPOSTSETIP config_load rfc1918






add_rfc1918_rule()
{
	local subnet="$1"
	local action="$2"

	if [ "$action" == "nomatch" ]; then
		ipset add "$IPSET_NAME" "$subnet" nomatch
	else
		ipset add "$IPSET_NAME" "$subnet"
	fi
}











detect_upstream()
{



	local interface="$1"


	#set -x

	subnets=$(ip route show dev "$interface"  | grep 'scope link' | awk '{print $1}')
	for subnet in $subnets; do


		# ipset test doesn't work for subnets, so strip out the subnet part
		# and test for that; add as exception if there's a match
		addr=$(echo $subnet | sed 's|/[0-9]\+$||')


if [ -n "$DEBUG" ]; then $ecmd "detecting upstream on $subnet [$addr]"; fi
if [ -n "$DEBUG" ]; then ipset test "$IPSET_NAME" $addr 2>/dev/null && $ecmd "add_rfc1918_rule $subnet nomatch UPSTEAMDETECT"; fi



		ipset test "$IPSET_NAME" $addr 2>/dev/null && add_rfc1918_rule $subnet nomatch
	done



}
#logger -t BCP "testdetectup ipset-test $IPSET_NAME $addr 2>/dev/null && add_bcp38_rule $subnet nomatch"





add_rfc1918_blackhole() {

	: #[ -n "$DEBUG" ] && $ecmd "DBG add-blackhole $1 int: $interface"
}
#NOTE: this is per section ~ possibly whole 'method' and skip nomatch
# ip route add blackhole 202.54.5.2/29
# ip route add blackhole from 202.54.1.2
# ip rule add blackhole to 10.18.16.1/29
#?ip rule add blackhole to 65.21.34.4





run() {


    	local section="$1"
    	local enabled
	local interface
	local detect_upstream
	config_get_bool enabled "$section" enabled 0
	config_get interface "$section" interface
	config_get detect_upstream "$section" detect_upstream


	#logger -t $TSNAME "setup-iface: $interface"
	[ -n "$DEBUG" ] && $ecmd "$TSNAME setup-iface: $interface en:$enabled int:$interface stop:$STOP dtcup:$detect_upstream"

	if [ "$enabled" -eq "1" -a -n "$interface" -a -z "$STOP" ] ; then
		setup_ipset
		setup_iptables "$interface"

		config_list_foreach "$section" match add_rfc1918_rule match
		config_list_foreach "$section" nomatch add_rfc1918_rule nomatch


		##########ADDEDNOACTIONTEST  NOTE: this is per section ~ possibly whole 'method' and skip nomatch
		config_list_foreach "$section" blackhole add_rfc1918_blackhole blackhole


		#[ "$detect_upstream" -eq "1" ] && $ecmd "DBG detect_upstream $interface"
		[ "$detect_upstream" -eq "1" ] && detect_upstream "$interface"
	fi



	#exit 0
}








setup_ipset()
{
	ipset create "$IPSET_NAME" hash:net family ipv4
	ipset flush "$IPSET_NAME"
}







setup_iptables()
{


	local interface="$1"
	iptables -N "$IPTABLES_CHAIN" 2>/dev/null
	iptables -F "$IPTABLES_CHAIN" 2>/dev/null



	iptables -I output_rule -m conntrack --ctstate NEW -j "$IPTABLES_CHAIN"
	iptables -I input_rule -m conntrack --ctstate NEW -j "$IPTABLES_CHAIN"
	iptables -I forwarding_rule -m conntrack --ctstate NEW -j "$IPTABLES_CHAIN"



	######################## always accept DHCP traffic
	#iptables -A "$IPTABLES_CHAIN" -p udp --dport 67:68 --sport 67:68 -j RETURN
	#iptables -A "$IPTABLES_CHAIN" -o "$interface" -m set --match-set "$IPSET_NAME" dst -j REJECT --reject-with icmp-net-unreachable
	#iptables -A "$IPTABLES_CHAIN" -i "$interface" -m set --match-set "$IPSET_NAME" src -j DROP




	iptables -A "$IPTABLES_CHAIN" -p udp --dport 67:68 --sport 67:68 -j RETURN

	#! -i eth1 not needed ?


	if [ ! -z "$FWCUSTOM1918LOG" ]; then #FWCUSTOM1918LOG=1

	iptables -A "$IPTABLES_CHAIN" -o "$interface" -m set --match-set "$IPSET_NAME" dst -j LOG --log-prefix "OUT-$TSNAME " #NOINEND
	iptables -A "$IPTABLES_CHAIN" -i "$interface" -m set --match-set "$IPSET_NAME" src -j LOG --log-prefix "IN-$TSNAME "


	fi



	iptables -A "$IPTABLES_CHAIN" -o "$interface" -m set --match-set "$IPSET_NAME" dst -j REJECT --reject-with icmp-net-unreachable
	iptables -A "$IPTABLES_CHAIN" -i "$interface" -m set --match-set "$IPSET_NAME" src -j DROP



}
















destroy_ipset()
{
	ipset flush "$IPSET_NAME" 2>/dev/null
	ipset destroy "$IPSET_NAME" 2>/dev/null
}






destroy_iptables()
{
	iptables -D output_rule -m conntrack --ctstate NEW -j "$IPTABLES_CHAIN" 2>/dev/null
	iptables -D input_rule -m conntrack --ctstate NEW -j "$IPTABLES_CHAIN" 2>/dev/null
	iptables -D forwarding_rule -m conntrack --ctstate NEW -j "$IPTABLES_CHAIN" 2>/dev/null
	iptables -F "$IPTABLES_CHAIN" 2>/dev/null
	iptables -X "$IPTABLES_CHAIN" 2>/dev/null
}






writebcpconfig() {

cat <<TTT
config $tsname
	option enabled 1
	option interface 'eth1'
	option detect_upstream 1
	list match '127.0.0.0/8'
	list match '192.0.2.0/24'    # RFC 5737
	list match '198.51.100.0/24' # RFC 5737
	list match '203.0.113.0/24'  # RFC 5737
	list match '192.168.0.0/16'  # RFC 1918
	list match '10.0.0.0/8'      # RFC 1918
	list match '172.16.0.0/12'   # RFC 1918
	list match '169.254.0.0/16'  # RFC 3927

# 	list nomatch '172.26.0.0/21' # Example of something not to match
#NONSTOCKWIP	list blackhole '172.16.0.0/12'   # RFC 1918
TTT
}
#[root@dca632 /usbstick 45°]# cat /etc/config/bcp38







runsetupchecks() {

	local ISSUES=

	if [ ! -f /root/.firewall.custom.setup.$tsname ]; then

		if [ -z "$(command -v ipset)" ]; then ISSUES="${ISSUES} ipsetnotinstalled"; fi


		#################################### add ipset@config logmatches-limit BELOW wandetectprobablyalsoruntime
		#######add wan detect fixup iface wan@config if not in run.sh etc.
		######################################################################
		#if [ "$(uci get network.wan.ifname)" != "eth1" ]; then
		#	$ecmd "wanif not eth1 WIP"
        	#############DETECT IF BCP IS ALREADY INSTALLED
        	#elif uci show firewall | grep -q 'bcp38/run.sh'; then
        	#    $ecmd "bcp is already installed"
        	#else
        	#BELOWRUNSCRIPT
		#fi
		###NOTE setupchecks were here /etc/config/SNAME + custscript@/etc/custom/firewall.custom.ABC


		if [ -z "$ISSUES" ] && [ ! -f /etc/config/$tsname ]; then

		        #####@@@NOTE: NEEDFLAGFILEorINHERITLOGICifFWCUSTOM1918changes

			#####runtimealsodetectwannamesandherePROBABLYwriteMULTIsections
			#####OR IGNOREWANIFALTOGHETHEROPT in CONFIG@dynamic

			$ecmd "/etc/config/$tsname [create]"
                	writebcpconfig > /etc/config/$tsname

                	if ! uci show $tsname | grep "$tsname.@$tsname\[0\].enabled=" | grep -q "'1'"; then
                    		uci -q set $tsname.@$tsname[0].enabled='1'
                    		uci commit $tsname
                	fi


                	#OLD touch /root/.$(basename $0).$tsname.setup #WIPNOCHECKYET

		elif [ -z "$ISSUES" ] && [ -f /etc/config/$tsname ]; then
			$ecmd "/etc/config/$tsname [present]"
        	fi




		#touch /root/.firewall.custom.setup.$tsname
	fi




	if [ -z "$ISSUES" ]; then
		touch /root/.firewall.custom.setup.$tsname
	fi



}









listwanifs() { #NOTE DEBUGGING TEST LOGIC FOR DYNAMIC @ EACHRUN and/or SETUP #NOTE MOVE TO custfunc.sh or custfunc.fw.sh

	case "$1" in
		routenonprivate)
			:
		;;

	esac

}
#METHOD 1 uci show or jsoninternal get wanif etc
#METHOD 2 ip/6 route
#METHOD 3 list all ifnames without public prefixes


#listwanifs
#$ecmd "FISH"; exit 0









#set -x



#@firewall.custom eval `grep '^FWCUSTOM1918=' /root/wrt.ini 2>/dev/null`
eval `grep '^FWCUSTOM1918LOG=' /root/wrt.ini 2>/dev/null`

tsname="rfc1918"
TSNAME="RFC1918"


if uci show firewall | grep -q 'bcp38/run.sh'; then
	$ecmd "bcp is already installed"
	exit 0
fi







#DEBUGONLY #$ecmd "TESTEXIT"; exit 0
#DEBUG=1
#rm /root/.firewall.custom.setup.$tsname 2>/dev/null




runsetupchecks



while read ip4upiface; do

	if [ "$(uci -q get $tsname.@$tsname[0].interface)" != "$ip4upiface" ]; then
		echo "$(uci -q get $tsname.@$tsname[0].interface) != $ip4upiface"
		logger -t $TSNAME "$(uci -q get $tsname.@$tsname[0].interface) != $ip4upiface"
		#NEEDTODESTROYALSOHERE
		exit 0
	else
		INITIFACE="$INITIFACE $ip4upiface"
	fi

done <<FISH
$(ip route | grep via | cut -d' ' -f5)
FISH
#$(ip route | grep default | cut -d' ' -f5)
#ip addr | grep 'inet ' | grep -v 'host lo' | grep -Ev '(br-lan)' | tr -s '\t' ' ' | cut -d' ' -f3,8
#ip route | grep via | cut -d' ' -f5




#logger -t $SNAME "init:$INITIFACE log:${FWCUSTOM1918LOG:-off} chain:$IPTABLES_CHAIN"
logger -t $TSNAME "init:$INITIFACE log:${FWCUSTOM1918LOG:-off} chain:$IPTABLES_CHAIN"







########3#MOVEDOWNPOSTSETIP-was-WAYUPTOP #config_load rfc1918
config_load $tsname



destroy_iptables
destroy_ipset
config_foreach run $tsname




############### DEBUG


#echo "iptables-save -c | grep -i \"$TSNAME\""
#iptables-save -c | grep -i "$TSNAME"


exit 0















################################ BCP ORIGINAL SECTION
################################ BCP ORIGINAL SECTION
################################ BCP ORIGINAL SECTION











#eval `grep '^FWCUSTOM1918=' $INIFILE 2>/dev/null`
eval `grep '^FWCUSTOM1918=' /root/wrt.ini 2>/dev/null`


if [ ! -z "$FWCUSTOM1918" ]; then

    tsname="rfc1918"
    TSNAME="RFC1918"

    BCPSCRIPT="/etc/custom/firewall.custom.$tsname.sh" #BCPSCRIPT="/usr/lib/bcp38/run.sh"


    if [ -f "${BCPSCRIPT}" ]; then



	if [ "$(uci get network.wan.ifname)" != "eth1" ]; then
		$ecmd "wanif not eth1 WIP"
		#return 1
		#fi

        #DETECT IF BCP IS ALREADY INSTALLED


        elif uci show firewall | grep -q 'bcp38/run.sh'; then
            $ecmd "bcp is already installed"
        else





            if [ ! -f /etc/config/$tsname ]; then












writebcpconfig() {

cat <<TTT
config $tsname
	option enabled 1
	option interface 'eth1'
	option detect_upstream 1
	list match '127.0.0.0/8'
	list match '192.0.2.0/24'    # RFC 5737
	list match '198.51.100.0/24' # RFC 5737
	list match '203.0.113.0/24'  # RFC 5737
	list match '192.168.0.0/16'  # RFC 1918
	list match '10.0.0.0/8'      # RFC 1918
	list match '172.16.0.0/12'   # RFC 1918
	list match '169.254.0.0/16'  # RFC 3927

# 	list nomatch '172.26.0.0/21' # Example of something not to match

TTT
}
#[root@dca632 /usbstick 45°]# cat /etc/config/bcp38


                $ecmd "writing /etc/config/$tsname"
                writebcpconfig > /etc/config/$tsname

		        #@@@NOTE: NEEDFLAGFILEorINHERITLOGICifFWCUSTOM1918changes
                if ! uci show $tsname | grep "$tsname.@$tsname\[0\].enabled=" | grep -q "'1'"; then
                    uci -q set $tsname.@$tsname[0].enabled='1'
                    uci commit $tsname
                fi

                touch /root/.$(basename $0).$tsname.setup #WIPNOCHECKYET
            fi

            $ecmd "rfc-1918 reload" #!script must check not enabled!!!
            sh ${BCPSCRIPT}

        fi


    else
        $ecmd "rfc-1918 no script: ${BCPSCRIPT}"
    fi

fi














#################################### add ipset@config logmatches-limit
#add wan detect fixup iface wan@config if not in run.sh etc.
#UCIDEFAULTS adds firewall only
####################################################################################
#ipset -L bcp38-ipv4
#iptables-save -c | grep -i BCP
####################################################################################
#ping 172.16.6.6
#dmesg
####################################################################################
#bcp38.@bcp38[0]=bcp38
#bcp38.@bcp38[0].enabled='1'
#bcp38.@bcp38[0].interface='eth1'
#bcp38.@bcp38[0].detect_upstream='1'
#bcp38.@bcp38[0].match='127.0.0.0/8' '192.0.2.0/24' '198.51.100.0/24' '203.0.113.0/24' '192.168.0.0/16' '10.0.0.0/8' '172.16.0.0/12' '169.254.0.0/16'
####################################################################################




#config bcp38
#	option enabled 1
#	option interface 'eth1'
#	option detect_upstream 1
#	list match '127.0.0.0/8'
#	list match '192.0.2.0/24'    # RFC 5737
#	list match '198.51.100.0/24' # RFC 5737
#	list match '203.0.113.0/24'  # RFC 5737
#	list match '169.254.0.0/16'  # RFC 3927
	##list match '192.168.0.0/16'  # RFC 1918
	##list match '10.0.0.0/8'      # RFC 1918
	##list match '172.16.0.0/12'   # RFC 1918

# 	list nomatch '172.26.0.0/21' # Example of something not to match
#	There is a dhcp trigger to do this for the netmask of a
#	double natted connection needed

#       You can only specify IPv4 addresses here - for IPv6, only source
#       specific default routes will be installed, which achieves the same
#       without needing any firewall routes.

#	I will argue that this level of indirection doesn't scale
# 	very well - see how to block china as an example
#	http://www.okean.com/china.txt
####################################################################################







#firewall.bcp38=include
#firewall.bcp38.type='script'
#firewall.bcp38.path='/usr/lib/bcp38/run.sh'
#firewall.bcp38.family='IPv4'
#firewall.bcp38.reload='1'
####################################################################################
####!/bin/sh /etc/rc.common
#START=20
#USE_PROCD=1
#NAME=bcp38
#service_triggers()
#{
#	procd_add_config_trigger "config.change" "bcp38" /etc/init.d/firewall reload
#}
####################################################################################














#iptables-save -c | grep -i BCP
#traceroute 172.16.6.6
#ipset -L bcp38-ipv4
#ipset test bogon_6 fe80:0000:0000:0000:0000:0000:0000:010c



########### dumprecordsgeo "ZZ" "4"
#0.0.0.0-0.255.255.255
#10.0.0.0-10.118.118.255
#10.118.121.0-10.118.129.255
#10.118.131.0-10.255.255.255
#100.64.0.0-100.127.255.255
#127.0.0.0-127.255.255.255
#169.254.0.0-169.254.255.255
#172.16.0.0-172.31.255.255
#192.0.0.0-192.0.0.255
#192.0.2.0-192.0.2.255
#192.88.99.0-192.88.99.255
#192.168.0.0-192.168.255.255
#198.18.0.0-198.19.255.255
#198.51.100.0-198.51.100.255
#203.0.113.0-203.0.113.255
#224.0.0.0-255.255.255.255
########### dumprecordsgeo "ZZ" "6"
#fc00::-fdff:ffff:ffff:ffff:ffff:ffff:ffff:ffff
#fe80::-febf:ffff:ffff:ffff:ffff:ffff:ffff:ffff


#A1 satellites
#ZZ local




#######################################################
# ip route add blackhole 202.54.5.2/29
# ip route add blackhole from 202.54.1.2
# ip rule add blackhole to 10.18.16.1/29



#?ip rule add blackhole to 65.21.34.4

















# uci -N show dhcp.@ipset[0] #> uci -N show dhcp.@dnsmasq[0].ipset
###############################dhcp.@ipset[0]=ipset
###############################dhcp.@ipset[0].name='ss_rules_dst_forward' 'ss_rules6_dst_forward'
###############################dhcp.@ipset[0].domain='telegram.org' 'linkedin.com'












