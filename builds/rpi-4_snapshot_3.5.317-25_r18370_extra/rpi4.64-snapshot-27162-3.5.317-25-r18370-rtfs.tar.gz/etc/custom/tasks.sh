#!/bin/sh
ecmd="echo "
i=$(basename $0)
if [ -x /etc/custom/custfunc.sh ]; then
	. /etc/custom/custfunc.sh
	ecmd="echm ${i} "
fi




eval $(grep '^NOTASKS' /root/wrt.ini 2>/dev/null)
eval $(grep '^TASKS_LOG_SUMMARY' /root/wrt.ini 2>/dev/null)
eval $(grep '^TASKS_STDOUT_STDERR' /root/wrt.ini 2>/dev/null)
if [ ! -z "$NOTASKS" ]; then
	exit 0
fi





























ffdir="/root"


#############################################################
now=$(printf "%d" $(date +%H%M))
today="`date +%Y%m%d`"
Dd="`date +%d`"




DH="`date +%H`"
DM="`date +%M`"
DW="`date +%W`"
fD="/tmp"

fP="/tmp/`basename $0`"; mkdir -p $fP #or dont have slash
DF="`date +%Y%m%d-%H%M`" #date full



















isok() {

local FN="isok"; #$ecmd "$FN: ${*}"; sleep 2

if [ -z "$1" ]; then $ecmd "param 1 [missing]" && return 1; fi
if [ -z "$2" ]; then $ecmd "param 2 [missing]" && return 1; fi


case "$1" in
	link)
		:
	;;
	file)
		:
	;;
	ff|flagfile)
		if [ ! -f "$2" ]; then return 1; fi
		#if [ ! -f "$2" ]; then
		#	echo "DEBUG: $2 NOFILE"
		#	return 1
		#else
		#	echo "DEBUG: $2 ISFILE"
		#	return 0
		#fi
	;;
	dir) if [ ! -d "$2" ]; then return 1; fi; ;;
	*)
		echo "$FN invalid case $1"; return 1
	;;
esac

return 0

}






croncheck() {

	#1 cmdline aka whole string after time
	#2 optional time?

	if [ -z "$1" ]; then echo "no job passed"; return 1; fi
	if ! crontab -l &>/dev/null; then echo "crontab -l issue"; return 1; fi

	jobsmatch=$(crontab -l | cut -d' ' -f6- | grep "$1" | wc -l)
	if [ "$jobsmatch" -eq 0 ]; then echo "no-matching-jobs: $1 $jobsmatch"; return 2; fi

	echo "jobs-found: $jobsmatch"
	###################################@?202111> gt 0? if [ "$jobsmatch" -gt 1 ]; then
	if [ "$jobsmatch" -gt 1 ]; then
    		echo "many-matching-jobs: $1 $jobsmatch"; return 2
	fi

	if crontab -l | grep -q "$1"; then
		echo "jobfound: " #echo "allmatch"
    		#crontab -l | grep "$1"
	else
		echo "jobnotfound: $1"
		#return 1
	fi

	return 0

}







croninsertline() {

	#$ecmd "adding crontab tasks.sh"
	echo "${*}" > /tmp/crontab.new
	if [ -f /etc/crontabs/root ]; then
		#$ecmd "Existing crontabs.... migrating"
		$ecmd "Setting up cron: ${*}"
		cat /etc/crontabs/root >> /tmp/crontab.new
	fi
	cat /tmp/crontab.new > /etc/crontabs/root; rm /tmp/crontab.new

}





cronlineadd() {

	local FN="cronlineadd"

	paramC=$(echo  "${1}" | wc -w)
	#echo "$FN> params: $paramC"

	if [ "$paramC" -lt 6 ]; then echo "$FN> noenoughvalues: $paramC"; return 1; fi

	if crontab -l | grep -x -F -q "${*}"; then
    		#WAS0 FOR CRONTCHANGES echo "cronjob: ${*} [present]"; return 0
    		echo "cronjob: ${*} [present]"; return 5
	else
    		echo "cronjob: ${*} [add]"
    		croninsertline "${*}"
    		return 0
	fi

	return 0

}

#WAS!$(echo ${1} | wc -w) #AST!$(echo -e ${1} | wc -w) #NOPEwCALLnoINCOM$(echo  "${*}" | wc -w)








echL() {

	local MSG="${1}"; shift

    	case "${1}" in
		verbose) if [ ! -z "$VERBOSE" ]; then echo "V:: $MNAME> $MSG"; fi; ;;
        	debug) if [ ! -z "$DEBUG" ]; then echo "D:: $MNAME> $MSG"; fi; ;;
		*|msg) echo "::: $MNAME> $MSG"; ;; #msghackedintoheretemp
    	esac

    	case "${1}" in
    		log) logger -t "$MNAME" ":::> $MSG"; return 0; ;;
	esac

}





MNAME="${iM-"$(basename $0)"}"









tasks_is_setup() {

	local FN="tasks_is_setup"


	local setupFF="${ffdir:-"/root"}/.${iM}.setup"
	
	if isok ff "${setupFF}"; then echL "setup-pre: $setupFF" debug; return 0; fi
	### if isok ff "${setupFF}"; then echL "setup-pre: $setupFF" debug; return 1WAS1?; fi


	echL "$FN> run FF:$setupFF"







	#!!!experimental@tasks/samples or tasks/user? || hashcompare on firstboot copy
	echL "check sysupgrade.conf /root/tasks/ $(grep '/root/tasks/' /etc/sysupgrade.conf)" debug
	if [ -z "$(grep '/root/tasks/' /etc/sysupgrade.conf)" ]; then
		$ecmd "WARNING: /root/tasks/ [not_in_sysupgrade.conf]"
		echo "/root/tasks/" >> /etc/sysupgrade.conf
	fi ######/lib/upgrade/keep.d/busybox:/etc/crontabs/ #newishprobably@202109ish









	echL "check upgrade lists for crontab $(fgrep -r '/etc/crontabs' /lib/upgrade/keep.d/ /etc/sysupgrade.conf)" debug
	if [ -z "$(fgrep -r '/etc/crontabs' /lib/upgrade/keep.d/ /etc/sysupgrade.conf)" ]; then
		$ecmd "WARNING: /etc/crontabs [not_in_sysupgrade.conf]"
	fi ######/lib/upgrade/keep.d/busybox:/etc/crontabs/ #newishprobably@202109ish











	echL "check /etc/crontabs/root for tasks.sh" debug
	


	#“At 05:59 on Monday.”
	#cronlineadd "59 05 * * 1 /etc/custom/tasks.sh daily"


	cronlineadd "59 05 * * 1 /etc/custom/tasks.sh weekly" && CRONCHANGES=1
	cronlineadd "59 05 * * * /etc/custom/tasks.sh daily" && CRONCHANGES=1
	cronlineadd "59 * * * * /etc/custom/tasks.sh hourly" && CRONCHANGES=1



	#IFCHANGES
	if [ -n "$CRONCHANGES" ]; then
		echL "cron changes restart" debug #verbose
		/etc/init.d/cron restart
	else
		echL "cron changes [nope]"
	fi





	echL "check /root/tasks directory format" debug
	#$ecmd "Sliding across cron tasks dir: /etc/custom/tasks > /root/tasks"
	if [ -d "/root/tasks" ]; then
		#EARLYcreateOFNEWDIRSbreaksTHIS
		$ecmd "/root/tasks [present-nocopy]"
	elif [ -d /etc/custom/tasks ]; then
		$ecmd "/root/tasks from /etc/custom/tasks [copy]"
		mkdir -p /root/tasks /root/tasks/daily /root/tasks/hourly /root/tasks/weekly
		cp -arf /etc/custom/tasks/. /root/tasks/ 2>/dev/null
	else	
		$ecmd "/root/tasks [from manual create]"
		mkdir -p /root/tasks /root/tasks/daily /root/tasks/hourly /root/tasks/weekly
		echo "echo \"$(basename $0); $(uptime)\" > /dev/kmsg" > /root/tasks/hourly/uptimesample.sh
		chmod +x /root/tasks/hourly/uptimesample.sh
	fi
	



	#TESTINGREMOVEME
	#echo "echo \"$(basename $0); $(uptime)\" > /dev/kmsg" > /root/tasks/hourly/uptimesample.sh
	#chmod +x /root/tasks/hourly/uptimesample.sh



	touch "${setupFF}"; return 0


}
	



#ffpfx="$ffdir/.${iM}"
#local setupFF="${ffdir:-"/root"}/.${iM}.setup"
#if [ -f "${setupFF}" ]; then echo "setup-pre: $setupFF"; return 0; fi
############### ffdir="/root"
#############################################
#    FFinit="${ffpfx}.init"
#    if ! isok ff "${FFinit}"; then
#        echo "running init: ${FFinit}"
#        touch "${FFinit}"
#    else
#        echo "already init: ${FFinit}"
#    fi
#############################################
##croncheck '/etc/custom/tasks.sh'
###cronlinerem "59 05 * * 1 /etc/custom/tasks.sh"
#exit 0





















rundir() {

	#0.5 maybe a name of callerorcomment
	#1   dir
	#2   optional findstr

	FN="rundir";
	#$ecmd "$FN: ${*}"; #sleep 2

	if [ -z "$1" ]; then $ecmd "param 1 [missing]" && return 1; fi
	if [ ! -z "$2" ]; then
		: #$ecmd ">>> recieved findstr: $2"; #sleep 3;
	fi




	cmdoutputfileCt="/tmp/commandoutput"
	rm ${cmdoutputfileCt:-"fish"} 2>/dev/null






if [ ! -z "$2" ]; then


	echo "THISSECTIONNEEDSUPDATING"; exit 0


	jobnum="`find $1/$2 2>/dev/null | wc -l`"
	if [ $jobnum -gt 0 ]; then
		$ecmd "got jobs $jobnum"


		for z in `find $1/$2 2>/dev/null`; do
			if [ ! -x "$z" ]; then
				$emcd "script: $z [non-executable]"
			else

				$ecmd "################# running: $z"

				if [ ! -d "`dirname $z`/output/`basename $z`" ]; then
					$ecmd "Creating output dir `dirname $z`/output/`basename $z`"
					mkdir -p "`dirname $z`/output/`basename $z`"

				fi

				cmdoutputfile="`dirname $z`/output/`basename $z`/$DF.output"
				sh $z > /tmp/cmdout
				if [ "$retval" -eq 0 ]; then
					outlines="`cat /tmp/cmdout | wc -l`"
					$ecmd "success > $cmdoutputfile:$outlines"
					mv /tmp/cmdout $cmdoutputfile
				else
					$ecmd "fail  > $cmdoutputfile.failed:$outlines"
					mv /tmp/cmdout $cmdoutputfile.failed
				fi
				#sh $z
			fi
			sleep ${DBGSLP:-"0"}
		done

	else
		$ecmd "find $1/$2 2>/dev/null [zero-matches]"
	fi

else






	###./output/ jobnum=`ls -l $1 | grep -v '^d' | wc -l`
	jobnum=$(find $1/* -maxdepth 0 -type f 2>/dev/null | wc -l)
	if [ $jobnum -gt 0 ]; then

		$ecmd "$1 has $jobnum scripts"; sleep ${DBGSLP:-"0"}
		###!OUTPUT/for z in $1/*; do
		##############echo "find $1/* -maxdepth 0 -type f"
		for z in $(find $1/* -maxdepth 0 -type f 2>/dev/null); do
			#echo "Z: $z"

			#JSUM=


			if [ ! -x "$z" ]; then
				$ecmd "script: $z [non-executable]"
				JSUM="$(basename $z)[nonexe]"
				JSUMl="${JSUMl} ${JSUM}"
			else
				####################$ecmd "################# running: $z"
				echL "################# running: $z" verbose


				if [ ! -d "`dirname $z`/output/`basename $z`" ]; then
					$ecmd "Creating output dir `dirname $z`/output/`basename $z`"
					mkdir -p "`dirname $z`/output/`basename $z`"
				fi


				cmdoutputfile="`dirname $z`/output/`basename $z`/$DF.output"



				retval=
				#sh $z > /tmp/cmdout
				rm /tmp/cmdout 2>/dev/null
				rm /tmp/cmderr 2>/dev/null
				sh $z 1>/tmp/cmdout 2>/tmp/cmderr
				retval=$?
	



				#IF NO STDOUT THEN dont bother copying has REDIR or something + STDerr?(retval)
				outlines="`cat /tmp/cmdout | wc -l`"
				outlinesE="`cat /tmp/cmderr | wc -l`"


				JSUM="$(basename $z)[$retval:$outlines:$outlinesE]"
				JSUMl="${JSUMl} ${JSUM}"

				echL "$JSUM" verbose
				

				sepH="##############################################"
				sepI="##########"
				echo "$sepH ${sACTION} $JSUM" >> $cmdoutputfileCt
				echo "$sepI stdout" >> $cmdoutputfileCt
				cat /tmp/cmdout 2>/dev/null >> $cmdoutputfileCt
				echo "$sepI stderr" >> $cmdoutputfileCt
				cat /tmp/cmderr 2>/dev/null >> $cmdoutputfileCt
				#$cmdoutputfileCt


				if [ "$retval" -eq 0 ]; then
					if [ "$outlines" -gt 0 ]; then
						echL "success > $cmdoutputfile:$outlines" verbose
					else
						echL "success > nooutput" verbose
					fi
				else
					echL "fail > ${cmdoutputfile}.failed:$outlines" verbose
				fi

				if [ ! -z "$TASKS_STDOUT_STDERR" ]; then
					mv /tmp/cmdout ${cmdoutputfile}.stdout 2>/dev/null
					mv /tmp/cmderr ${cmdoutputfile}.stderr 2>/dev/null
				fi




			fi
			sleep ${DBGSLP:-"0"}
		done

	else
		$ecmd "$1 has $jobnum scripts"; sleep ${DBGSLP:-"0"}
	fi
fi
				


if [ ! -z "$JSUMl" ]; then
	
	### dated directory for all clutter
	OUT_THIS="$1/output/${DSi}"
	mkdir -p $OUT_THIS


	### common spot for many runs
	OUT_FULL_LOG="$1/output/summary_${DSi}_fulllog"






	if [ ! -z "$TASKS_LOG_SUMMARY" ]; then

	echL "${sACTION} $JSUMl $OUT_FULL_LOG" log
	###echL "${sACTION} $JSUMl" log

	fi



	echo "${DSi} ${sACTION} $JSUMl $OUT_FULL_LOG" >> $1/output/runlog
	echo "${DSi} ${sACTION} $JSUMl $OUT_FULL_LOG" >> /root/tasks/runlog



	echL "$OUT_FULL_LOG" verbose


	echo "### $JSUMl" >> $OUT_FULL_LOG
	echo "_____________________" >> $OUT_FULL_LOG
	echo "### $JSUMl" >> $OUT_FULL_LOG
	echo "_____________________" >> $OUT_FULL_LOG



	echo "### $JSUMl" >> $OUT_FULL_LOG
	cat ${cmdoutputfileCt:-"fish"} >> $OUT_FULL_LOG 2>/dev/null
	rm ${cmdoutputfileCt:-"fish"} 2>/dev/null




	echL "$JSUMl > $OUT_THIS/summary_${DSi}_status" debug
	echo "${DSi} ${sACTION} $JSUMl" >> $OUT_THIS/summary_${DSi}_status



fi

}










runtask() {

################## calls rundir seperate because furutre complex flagflile switches and echo comments etc
#1 comment
#2 dir
#3 flagfile
#4 optional findstr



	local FN="runtask"

if [ -z "$2" ]; then
	$ecmd "$FN: param2: dir [missing-or-z]" && return 2;
fi
if [ ! -z "$4" ]; then
	:	#$ecmd "findstr passed: $4" && sleep 2;
fi

if isok dir "$2"; then dirvalid="[ok]"; fi
if isok flagfile "$3"; then flagpresent="[present]"; fi






$ecmd "#########################################"
$ecmd "$FN: ${*}";
$ecmd "      comment: $1"
$ecmd "          dir: $2 $dirvalid"
$ecmd "     flagfile: $3 $flagpresent"
$ecmd "      findstr: ${4:-"optional"}"



if [ -z "$dirvalid" ]; then
	$ecmd "nodir: $2" && return 1
fi

if [ ! -z "$flagpresent" ]; then
	#$ecmd "flag exists: $3" && return 1

	[ -z "$FORCE" ] && $ecmd "flag exists: $3 [use force or remove]" && return 1
	[ -n "$FORCE" ] && $ecmd "flag exists: $3 [force given]"; rm $3
fi





echL "$FN: rundir $2 $4" debug #DBGONLY #$ecmd "$FN: rundir $2 $4" #DBGONLY
rundir "$2" $4


echL "touch $3" debug #$ecmd "touch $3"
touch "$3"


}



#$ecmd "touch $fP/$Dd"; touch "$fP/$Dd"
###DIR!$ecmd "DBG: touch $2"; touch $2













#sleep ${RCSLEEP:-0}

































pr_header() {
	local FN="pr_header"
$ecmd "###################################################### $FN";
$ecmd " tasks directory: $taskD"
$ecmd "     flag-prefix: $fP"
$ecmd "             now: $now"
$ecmd "           today: $today"
$ecmd "             day: $Dd"
$ecmd "            hour: $DH"
$ecmd "          minute: $DM"
sleep ${DBGSLP:-"0"}

}











usage() {
cat <<PPP
$0 [init|hourly|daily|weekly|monthly|flush] <force>
PPP
}


#flush rm -rf /root/tasks/*/output









DSi=$(date +%Y%m%d%H%M)
iM="$(basename $0)"
ffpfx="$ffdir/.${iM}"
logF="/restorefiles/tasks/logs/$(basename $0)_${DSi}.log"



#echo "DF: $DF" #DATEFULL-w-MINS 20211126-2030 #DW 45
#echo "Dh: $Dh" #Dh: 2021112620
Dh=`date +%Y%m%d%H`
#Dh=`date +%Y%m%d`
DD="`date +%d`"
#NEWNOTUSED? echo "DD: $DD"
#######################################
#DH="`date +%H`"
#DM="`date +%M`"
#DW="`date +%W`"
#fD="/tmp"
#fP="/tmp/`basename $0`"; mkdir -p $fP #or dont have slash
#DF="`date +%Y%m%d-%H%M`" #date full





taskD="/root/tasks" #!> ${taskD}sACTION #skDdaily="$taskD/daily" #skDhourly="$skD/hourly" #taskDweekly="$skD/weekly"

































parseallparams() {


	if [ "$#" -eq 0 ]; then
		#[ -n "$DEBUG" ] && echo "noparams given"
		echo "noparams given #RETURN 0 FOR NOW"
		usage
		return 0
	fi

	while [ "$#" -gt 0 ]; do
		case "$1" in
		-h|--help|help) usage && exit 0; ;;
		-f|force) FORCE=1; shift 1; ;;
		-D|debug) DEBUG=1; RUNOPTS="${RUNOPTS} debug"; shift; ;;
		-v|verbose) VERBOSE=1; shift; ;;
		-Q|quick) QUICK=1; shift ;;		
		init|flush|hourly|daily|weekly|monthly)
			sACTION="${1}"
			shift 1
		;;

		*) echo "unknown param: $1"; shift; ;;
		esac
	done

}

#-R) REFLECTORs="${REFLECTORs} ${2}"; shift 2; ;;








ALLPARAMS=${*}
parseallparams ${ALLPARAMS}











if [ -z "$sACTION" ]; then
	echo "no_sACTION"; exit 0
fi
#usage





#DEBUG=1
if [ ! -z "$DEBUG" ]; then
	echo ">debugging enabled"; sleep 1
	DBGSLP=1
	VERBOSE=1
	#$ecmd "init actions:${*} $logF"
fi #if [ ! -z "$DEBUG" ]; then $ecmd "init actions:${*} $logF"; fi

if [ ! -z "$DEBUG" ]; then $ecmd "$sACTION PARAMS:${*} L:${logF}"; fi









case "$sACTION" in
	flush) ######################################################## INIT
		echo "flush needs testing"
		rm -rf /root/tasks/*/output 2>/dev/null
		rm /root/tasks/runlog 2>/dev/null
		find /root/tasks
	;;



	init) ######################################################## INIT



	### WORKAROUND
	##########################################HACKforANEWdir@root/tasks exists IEweeklyREMOVElater		
	#BREAKSisFROMsysupLOGIC
	### mkdir -p /root/tasks /root/tasks/daily /root/tasks/hourly /root/tasks/weekly /root/tasks/monthly



	#DEMO echo "DBGrm /root/.tasks.sh.setup"; sleep 2; rm /root/.tasks.sh.setup 2>/dev/null
	if tasks_is_setup; then
		#[ -n "$DEBUG" ] && $ecmd "EEE ${iM} we are setup"
		echL "LLL ${iM} we are setup" ################################ usage
		###setupFF="${ffdir:-"/root"}/.${iM}.setup"
		#mkdir -p /root/tasks /root/tasks/daily /root/tasks/hourly /root/tasks/weekly /root/tasks/monthly
	else
		echL "setupissues [exit]"; exit 0
	fi
	

	exit 0
	#?> crontRESTART

	;;




	hourly|daily|weekly|monthly)
		:
	;;
	*)
		echo "################# nope $0 ${*}"; usage; exit 2
	;;
esac






case "$sACTION" in
	hourly)
		dstamp=`date +%Y%m%d%H`
	;;
	daily)
		dstamp=`date +%Y%m%d`
	;;

	weekly)
		dstamp=`date +%Y%W`
	;;

	monthly)	
		dstamp=`date +%Y%m`
	;;
esac





	[ -n "$DEBUG" ] && pr_header #pr_header
	###@runtask
	###[ -n "$FORCE" ] && [ -f "$fP/$dstamp" ] && echo "force rm $fP/$dstamp" && rm "$fP/$dstamp" 2>/dev/null
	###[ -z "$FORCE" ] && [ -f "$fP/$dstamp" ] && echo "ffearlyprint $fP/$dstamp use 'force' or remove"	

	taskDj="${taskD}/${sACTION}"





	$ecmd "run-tasks:$sACTION dstamp:$dstamp tdj:$taskDj"
	#echL "run-tasks:$sACTION dstamp:$dstamp tdj:$taskDj" log
		#$ecmd "DBG: runtask $sACTION all $taskDdaily $fP/$dstamp "; #sleep 3
		#runtask "runtask${sACTION} *" "${taskD}/${sACTION}" "$fP/$dstamp" ""; #sleep 3
	###############echL "run-tasks:$sACTION dstamp:$dstamp" log
		###runtask "runtask${sACTION} *" "${taskD}/${sACTION}" "$fP/$dstamp" ""; #sleep 3
		#########runtask "runtask${sACTION} *" "$taskDdaily" "$fP/$dstamp" ""; #sleep 3
		###echL "run-tasks:$sACTION dstamp:$dstamp dir:$taskD" log



case "$sACTION" in
	daily)  ########################################################## DAILY
		runtask "runtask${sACTION} *" "${taskDj}" "$fP/$dstamp" ""
	    ;;
    	hourly) ########################################################## HOURLY
		runtask "runtask${sACTION} *" "${taskDj}" "$fP/$dstamp" ""
	;;
	weekly) ########################################################### WEEKLY
		runtask "runtask${sACTION} *" "${taskDj}" "$fP/$dstamp" ""
	;;
	monthly) ########################################################## MONTHLY
		runtask "runtask${sACTION} *" "${taskDj}" "$fP/$dstamp" ""
	;;
esac













exit 0






###################################################################################
#echo "######################## SETXXX"; sleep 2; set -x
#####################################logger -t $0 "run-tasks-called: dstamp:$DF dir:$taskD"
#$ecmd "             day: $Dd"
#$ecmd "            hour: $DH"
#$ecmd "          minute: $DM"

#DEMO echo "FORCE rm /tmp/tasks.sh/20211"; rm /tmp/tasks.sh/20211* 2>/dev/null; sleep 2







######################################################
#cronjobcnt=$(crontab -l | wc -l)
#$ecmd "jobs:$cronjobcnt"
######################################################
#if [ ! -z "$DEBUG" ]; then
#	$ecmd "$sACTION actions:${*} jobs:$cronjobcnt"
#	$ecmd "$sACTION actions:${*} L:${logF}"
#else
#	$ecmd "$sACTION actions:${*} jobs:$cronjobcnt"
#	$ecmd "$sACTION actions:${*} L:${logF}"
#fi




#logF="/SPAK"; $ecmd "STARTTEST3-with-logF" -L; sleep 2
#$ecmd "STARTTEST5-with-logF-onprevious" -L; sleep 2




#if echo "${*}" | grep -wq force; then FORCE=1; fi
#if echo "${*}" | grep -wq debug; then DEBUG=1; fi
#if [ -z "$1" ]; then
#	sACTION="init"
#elif [ ! -z "$1" ]; then
#	sACTION="${1}"
#fi











################################## STDOUTERRLOGIC1
rundirwstdouterrandoldstringsection() {

	#0.5 maybe a name of callerorcomment
	#1   dir
	#2   optional findstr

	FN="rundir";
	#$ecmd "$FN: ${*}"; #sleep 2

	if [ -z "$1" ]; then $ecmd "param 1 [missing]" && return 1; fi
	if [ ! -z "$2" ]; then
		: #$ecmd ">>> recieved findstr: $2"; #sleep 3;
	fi




	cmdoutputfileCt="/tmp/commandoutput"
	rm ${cmdoutputfileCt:-"fish"} 2>/dev/null






if [ ! -z "$2" ]; then


	echo "THISSECTIONNEEDSUPDATING"; exit 0


	jobnum="`find $1/$2 2>/dev/null | wc -l`"
	if [ $jobnum -gt 0 ]; then
		$ecmd "got jobs $jobnum"


		for z in `find $1/$2 2>/dev/null`; do
			if [ ! -x "$z" ]; then
				$emcd "script: $z [non-executable]"
			else

				$ecmd "################# running: $z"

				if [ ! -d "`dirname $z`/output/`basename $z`" ]; then
					$ecmd "Creating output dir `dirname $z`/output/`basename $z`"
					mkdir -p "`dirname $z`/output/`basename $z`"

				fi

				cmdoutputfile="`dirname $z`/output/`basename $z`/$DF.output"
				sh $z > /tmp/cmdout
				if [ "$retval" -eq 0 ]; then
					outlines="`cat /tmp/cmdout | wc -l`"
					$ecmd "success > $cmdoutputfile:$outlines"
					mv /tmp/cmdout $cmdoutputfile
				else
					$ecmd "fail  > $cmdoutputfile.failed:$outlines"
					mv /tmp/cmdout $cmdoutputfile.failed
				fi
				#sh $z
			fi
			sleep ${DBGSLP:-"0"}
		done

	else
		$ecmd "find $1/$2 2>/dev/null [zero-matches]"
	fi

else






	###./output/ jobnum=`ls -l $1 | grep -v '^d' | wc -l`
	jobnum=$(find $1/* -maxdepth 0 -type f 2>/dev/null | wc -l)
	if [ $jobnum -gt 0 ]; then

		$ecmd "$1 has $jobnum scripts"; sleep ${DBGSLP:-"0"}
		###!OUTPUT/for z in $1/*; do
		##############echo "find $1/* -maxdepth 0 -type f"
		for z in $(find $1/* -maxdepth 0 -type f 2>/dev/null); do
			#echo "Z: $z"

			#JSUM=


			if [ ! -x "$z" ]; then
				$ecmd "script: $z [non-executable]"
				JSUM="$(basename $z)[nonexe]"
				JSUMl="${JSUMl} ${JSUM}"
			else
				####################$ecmd "################# running: $z"
				echL "################# running: $z" verbose


				if [ ! -d "`dirname $z`/output/`basename $z`" ]; then
					$ecmd "Creating output dir `dirname $z`/output/`basename $z`"
					mkdir -p "`dirname $z`/output/`basename $z`"
				fi


				cmdoutputfile="`dirname $z`/output/`basename $z`/$DF.output"



				retval=
				#sh $z > /tmp/cmdout
				rm /tmp/cmdout 2>/dev/null
				rm /tmp/cmderr 2>/dev/null
				sh $z 1>/tmp/cmdout 2>/tmp/cmderr
				retval=$?




				#IF NO STDOUT THEN dont bother copying has REDIR or something + STDerr?(retval)
				outlines="`cat /tmp/cmdout | wc -l`"
				outlinesE="`cat /tmp/cmderr | wc -l`"


				JSUM="$(basename $z)[$retval:$outlines:$outlinesE]"
				JSUMl="${JSUMl} ${JSUM}"

				echL "$JSUM" verbose


				sepH="##############################################"
				sepI="##########"
				echo "$sepH ${sACTION} $JSUM" >> $cmdoutputfileCt
				echo "$sepI stdout" >> $cmdoutputfileCt
				cat /tmp/cmdout 2>/dev/null >> $cmdoutputfileCt
				echo "$sepI stderr" >> $cmdoutputfileCt
				cat /tmp/cmderr 2>/dev/null >> $cmdoutputfileCt
				#$cmdoutputfileCt



				if [ "$retval" -eq 0 ]; then
					if [ "$outlines" -gt 0 ]; then
						#$ecmd "success > $cmdoutputfile:$outlines"
						echL "success > $cmdoutputfile:$outlines" verbose
						mv /tmp/cmdout $cmdoutputfile #2>/dev/null
						mv /tmp/cmderr ${cmdoutputfile}.err #2>/dev/null
					else
						echL "success > nooutput" verbose
					fi
				else
					echL "fail > ${cmdoutputfile}.failed:$outlines" verbose
					mv /tmp/cmdout ${cmdoutputfile}.failed #2>/dev/null
					mv /tmp/cmderr ${cmdoutputfile}.err #2>/dev/null
				fi






			fi
			sleep ${DBGSLP:-"0"}
		done

	else
		$ecmd "$1 has $jobnum scripts"; sleep ${DBGSLP:-"0"}
	fi
fi



if [ ! -z "$JSUMl" ]; then

	### dated directory for all clutter
	OUT_THIS="$1/output/${DSi}"
	mkdir -p $OUT_THIS


	### common spot for many runs
	OUT_FULL_LOG="$1/output/summary_${DSi}_fulllog"






	if [ ! -z "$TASKS_LOG_SUMMARY" ]; then

	echL "${sACTION} $JSUMl $OUT_FULL_LOG" log
	###echL "${sACTION} $JSUMl" log

	fi



	echo "${DSi} ${sACTION} $JSUMl $OUT_FULL_LOG" >> $1/output/runlog
	echo "${DSi} ${sACTION} $JSUMl $OUT_FULL_LOG" >> /root/tasks/runlog



	echL "$OUT_FULL_LOG" verbose


	echo "### $JSUMl" >> $OUT_FULL_LOG
	echo "_____________________" >> $OUT_FULL_LOG
	echo "### $JSUMl" >> $OUT_FULL_LOG
	echo "_____________________" >> $OUT_FULL_LOG



	echo "### $JSUMl" >> $OUT_FULL_LOG
	cat ${cmdoutputfileCt:-"fish"} >> $OUT_FULL_LOG 2>/dev/null
	rm ${cmdoutputfileCt:-"fish"} 2>/dev/null




	echL "$JSUMl > $OUT_THIS/summary_${DSi}_status" debug
	echo "${DSi} ${sACTION} $JSUMl" >> $OUT_THIS/summary_${DSi}_status



fi

}

































