#!/bin/sh
ecmd="echo "
i=$(basename $0)
if [ -x /etc/custom/custfunc.sh ]; then
	. /etc/custom/custfunc.sh #echo "Sourcing /etc/custom/custfunc.sh"
	ecmd="echm ${i} "
else
	: #"NOT Sourcing /etc/custom/custfunc.sh" && sleep 2
fi
#test -f /root/.firstboot.$i && exit 0

Dd="`date +%Y%m%d`"	; Dh="`date +%Y%m%d-%H`" ; D="`date +%Y%m%d-%h%m`" #opkgupdatecheck





#20200921 SED of usr/libexec/collectd/ > testing files/usr/libexec/collectd/sqm_collectd.sh







writelucistatisticssample() {

#$1 WANIF

    cat <<EOF > /etc/config/luci_statistics_sqmsample
config statistics 'collectd_exec'
        #option enable '0'
        option enable '1'

config collectd_exec_input
        option cmduser 'nobody'
        option cmdgroup 'nogroup'
        option cmdline '/usr/libexec/collectd/sqm_collectd.sh ${1:-eth1}'
        #option cmdline '/usr/libexec/collectd/sqm_collectd.sh eth0.2'
EOF

}






checknetstatus() {
ping -c 2 -W 2 google.com > /dev/null
if [ $? -ne 0 ]; then return 5; fi
return 0
}
#nc -z $ROUTERIP 22
#if [ $? -ne 0 ]; then return 6; fi
















$ecmd "FIXME sqm statistics 2 bugs ifname-early and enableOR@vpnslow lower pre defaults"
exit 0
















WANIF=$(uci -q show network.wan.ifname | cut -d"'" -f2)
if [ -z "$WANIF" ]; then
    $ecmd "no wan interface -> using eth1 and not enabling sqm"; sleep ${RCSLEEP:-0}; WANIF="eth1"
fi
$ecmd "wan ifname: $WANIF" #if uci show sqm | grep 'sqm.eth1.enabled=' | grep -q '1'; then #fi
#WASOFF #if [ -z "$WANIF" ]; then $ecmd "no wan interface -> cp $0 /etc/custom/startup/ ???"; sleep ${RCSLEEP:-0}; exit 0; fi






#@@@ needs wrt.ini sqmINTc sqmINTs etc... source

if opkg list-installed | grep -q '^luci-app-statistics'; then
    $ecmd "luci-app-statistics: [installed]"

    if opkg list-installed | grep -q 'collectd-mod-sqm'; then
        $ecmd "collectd-mod-sqm: [installed]"
	#set -x
	if ! uci show luci_statistics | grep -q 'exec_input.cmdline='; then

        $ecmd "configuring collectd-mod-sqm in luci_statistics exec $WANIF"

        uci -q set luci_statistics.collectd_exec.enable='1'
		uci -q set luci_statistics.collectd_exec_input=collectd_exec_input
		uci -q set luci_statistics.collectd_exec_input.cmduser='nobody'
		uci -q set luci_statistics.collectd_exec_input.cmdgroup='nogroup'
		uci -q set luci_statistics.collectd_exec_input.cmdline="/usr/libexec/collectd/sqm_collectd.sh $WANIF"
		uci commit luci_statistics

        #@>sqm vanilla setup but toggleexecbackoff
        #dorestart=1




        #@20200921 dorestart
        dorestart=1
        #$ecmd "restarting luci_statistics collectd"
		#/etc/init.d/luci_statistics restart
		#/etc/init.d/collectd restart

    else
        	$ecmd "collectd-mod-sqm in luci_statistics $WANIF [seems-setup]"
	fi

    fi


else
    $ecmd "luci-app-statistics: [not-installed]"

	$ecmd "writing /etc/config/statisticsexecsample"
	writelucistatisticssample
fi









if [ ! -z "$dorestart" ]; then
        $ecmd "restarting luci_statistics collectd"
		/etc/init.d/luci_statistics restart
		/etc/init.d/collectd restart
fi









SKIPTHISTESTINGINFILES() {

if ! grep -q '[ "$jsn" = "[]"  ] && return' /usr/libexec/collectd/sqm_collectd.sh; then
	$ecmd "collectd.sh [returnfix]"
    sed -i 's:jsn=$(tc -s -j qdisc show dev "$ifc") || return:jsn=$(tc -s -j qdisc show dev "$ifc") || return; [ "$jsn" = "[]"   ] \&\& return:g' /usr/libexec/collectd/sqm_collectd.sh

fi
#/usr/libexec/collectd/sqm_collectd.sh; > SYSYPGRADEorRESETUP
#/usr/libexec/collectd/sqm_collectd.sh
#jsn=$(tc -s -j qdisc show dev "$ifc") || return
#[ "$jsn" = "[]"  ] && return
#sed -i 's:'jsn=$(tc -s -j qdisc show dev "$ifc") || return':'jsn=$(tc -s -j qdisc show dev "$ifc") || return; [ "$jsn" = "[]"  ] && return':g' /usr/libexec/collectd/sqm_collectd.sh

}
















$ecmd "sqm enabling itself skip lower setup logic 202107openvpnslow FIXMEUPPERNOTICE"





if uci show sqm | grep -q ".enabled='1'"; then
    $ecmd "sqm seems setup"; exit 1
fi
if [ -f /etc/config/sqm-original ]; then
    $ecmd "script run previously [/etc/config/sqm-original]"; exit 0
fi







######################################################################################
$ecmd "sqm enabling itself skip lower setup logic 202107openvpnslow"
touch /root/.firstboot.$i
exit 0
#####################################################################################










########################/usr/lib/sqm/defaults.sh  > SYSYPGRADEorRESETUP
#SQM_VERBOSITY_MAX=10 /etc/init.d/sqm stop ; SQM_VERBOSITY_MAX=10 /etc/init.d/sqm start
preREQsqm="sqm-scripts sqm-scripts-extra luci-app-sqm"
preREQstatisticssqm="luci-app-statistics collectd-mod-sqm"
sqmDEF="/usr/lib/sqm/defaults.sh"
diffservis="diffserv4" #diffservis="diffserv8"
wanis=$(uci -q show network.wan.ifname | cut -d"'" -f2) #wanis="eth1"
wanwas=$(uci show sqm | grep '.interface=' | cut -d"'" -f2)
upwas=$(uci show sqm | grep '.upload=' | cut -d"'" -f2) #sqm.eth1.upload='17600'
downwas=$(uci show sqm | grep '.download=' | cut -d"'" -f2) #sqm.eth1.download='43500'
############# tba eth44linklayervalues







if checknetstatus && [ -x /bin/sqmauto.sh ]; then
	$ecmd "background the rest of this script"
	sh /bin/sqmauto.sh &
	upis="17900"
	downis="45500"
else
	$ecmd "background the rest of this script net not online"
	upis="17900"
	downis="45500"
fi







#diffservwas=""
cat /usr/lib/sqm/defaults.sh | grep -v '^#' | grep -q 'INGRESS_CAKE_OPTS="diffserv3"' && diffservwas="diffserv3"
cat /usr/lib/sqm/defaults.sh | grep -v '^#' | grep -q 'INGRESS_CAKE_OPTS="diffserv4"' && diffservwas="diffserv4"
cat /usr/lib/sqm/defaults.sh | grep -v '^#' | grep -q 'INGRESS_CAKE_OPTS="diffserv8"' && diffservwas="diffserv8"







if [ -z "$wanis" ]; then
    echo "wan interface undetermined [exit]"; exit 0
else
    echo "  current-system-wan: $wanis"
    echo "     current-sqm-wan: $wanwas"
fi









sqmvalueinfo() {

echo "#####################################"
echo "     current-sqm-wan: $wanwas"
echo "      current-sqm-up: $upwas"
echo "    current-sqm-down: $downwas"
echo "   current-sqm-diffs: $diffservwas"



echo "#####################################"
echo "         new-sqm-wan: $wanis"
echo "          new-sqm-up: $upis"
echo "        new-sqm-down: $downis"
echo "       new-sqm-diffs: $diffservis"

}










sqmdefaultsadjust() {
#1
#2
echo "########################## check: $1 for: $2"
cat $sqmDEF | grep -v '^#' | grep $1
echo "$sqmDEF change:$1 to:$2"; sleep 2 #echo "sed -i \"s/$1/$2/g\" $sqmDEF"; sleep 1
sed -i "s/$1/$2/g" $sqmDEF
echo "########################## check"
cat $sqmDEF | grep -v '^#' | grep $2
}











checkinstalled() {
for PKG in ${*}; do
if ! opkg list-installed | grep -q "^$PKG "; then
	echo "opkg update && opkg install $PKG"
else
	: #echo "$PKG [installed]"
fi
done
}









if [ "$diffservis" != "$diffservwas" ]; then
	sqmdefaultsadjust "$diffservwas" "$diffservis"
else
	: #echo "$sqmDEF diffserv [ok]"; sleep 2
fi









#################################################################20210731OOPS?

#@@@ 1 not 0 ???
if /etc/init.d/sqm enabled; then
	echo sqm [enabled]
else
	echo sqm [not-enabled]; #echo sqm [enabling]; /etc/init.d.sqm enable
    /etc/init.d/sqm enable
	dosqmrestart=1
    #/etc/init.d/sqm restart
fi
#/etc/init.d/sqm status >>> inactive | active with no instances




















if opkg list-installed | grep -q '^sqm-scripts'; then

	$ecmd "sqm [is-installed] setup for $WANIF"

	uci -q set sqm.$WANIF=queue
    if [ ! -z "$WANIF" ]; then
	    uci -q set sqm.$WANIF.enabled='1'
    else
	    uci -q set sqm.$WANIF.enabled='0'
    fi


	uci -q set sqm.$WANIF.interface="$WANIF"
	uci -q set sqm.$WANIF.download='43500'
	uci -q set sqm.$WANIF.upload='17600'
	uci -q set sqm.$WANIF.qdisc_advanced='0'
	uci -q set sqm.$WANIF.linklayer='none'
	uci -q set sqm.$WANIF.debug_logging='0'
	uci -q set sqm.$WANIF.verbosity='5'
	uci -q set sqm.$WANIF.qdisc='cake'
	uci -q set sqm.$WANIF.script='piece_of_cake.qos'
	uci -q set sqm.$WANIF.script='layer_cake.qos'
	uci commit sqm
	dosqmrestart=1
	#/etc/init.d/sqm restart

else
	$ecmd "sqm is not installed"
fi






if [ ! -z "$dosqmrestart" ]; then
        $ecmd "restarting sqm"
		/etc/init.d/sqm restart
fi














touch /root/.firstboot.$i
exit 0
#echo "end"
$ecmd "determine sqm interface [notgoingnear-sqm-setup] exit!"; exit 0
#sqm.eth1.script='layer_cake.qos' #<peice_of_cake.qos






