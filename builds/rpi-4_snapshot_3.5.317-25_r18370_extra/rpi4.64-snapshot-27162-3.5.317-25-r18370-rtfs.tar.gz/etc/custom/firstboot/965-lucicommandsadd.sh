#!/bin/sh
ecmd="echo "
i=$(basename $0)
if [ -x /etc/custom/custfunc.sh ]; then
	. /etc/custom/custfunc.sh #echo "Sourcing /etc/custom/custfunc.sh"
	ecmd="echm ${i} "
else
	: #"NOT Sourcing /etc/custom/custfunc.sh" && sleep 2
fi





#test -f /root/.firstboot.$i && exit 0





Dd="`date +%Y%m%d`"	; Dh="`date +%Y%m%d-%H`" ; D="`date +%Y%m%d-%h%m`" #opkgupdatecheck










commandaddecho() {

#$ecmd "echo info config file corrupts it"; exit 0

if [ -z "$1" ] || [ -z "$2" ]; then
    $ecmd "invalid luci-command: $1 $2"
    return 0
fi

if grep -q "$1" /etc/config/luci; then
    $ecmd "luci-command: $1 $2 [present]"; return 0
fi


$ecmd "adding luci-command: $1 $2"
echo "config command" >> /etc/config/luci
echo "  option name '"$1"'" >> /etc/config/luci
echo "  option command '"$2"'" >> /etc/config/luci
if [ ! -z "$3" ]; then
    echo "  option param '1'" >> /etc/config/luci
fi
if [ ! -z "$4" ]; then
    echo "  option public '1'" >> /etc/config/luci
fi
echo "" >> /etc/config/luci
}













ucicommandmod() {

	local CMDaction="${1}"
	local CMDname="${2}"
	local CMDhandle=

    #@checkpresentdupe@add+rem

	case "${CMDaction}" in

		remove)
			if uci show luci | grep command | grep '.name' | grep -q "$CMDname"; then
				cmdHANDLE=$(uci show luci | grep command | grep '.name' | grep "$CMDname" | cut -d'.' -f1,2)
				#echo "found $cmdHANDLE: $(uci show luci | grep command | grep '.name' | grep "$CMDname")"
				echo "Removing-cmd: $CMDname@$cmdHANDLE" > /dev/console
                uci -q delete ${cmdHANDLE}
				uci -q commit luci #uci revert luci
			else
				[ -n "$DEBUG" ] && echo "Removing-cmd: $CMDname@$cmdHANDLE [not-present]" > /dev/console
			fi
		;;

		add)

			local CMDbin="${3}"
			local CMDparam="${4:-0}"
			local CMDpublic="${5:-0}"
			if [ -z "$CMDbin" ]; then echo "param3-bin: [empty]"; return 1; fi


			#check it exists
			if uci show luci | grep command | grep '.name' | grep -q "$CMDname"; then
				cmdHANDLE=$(uci show luci | grep command | grep '.name' | grep "$CMDname" | cut -d'.' -f1,2)
				echo "Adding-cmd: $CMDname@$cmdHANDLE [already-exists]" >/dev/console
                uci -q delete ${cmdHANDLE}

                #RENABLE-ON_COMMITTESTFAIL
                #RENABLE-ON_COMMITTESTFAIL
                #RENABLE-ON_COMMITTESTFAIL
                #RENABLE-ON_COMMITTESTFAIL
                #RENABLE-ON_COMMITTESTFAIL

                #uci -q commit luci #uci revert luci

                #RENABLE-ON_COMMITTESTFAIL
                #RENABLE-ON_COMMITTESTFAIL
                #RENABLE-ON_COMMITTESTFAIL
                #RENABLE-ON_COMMITTESTFAIL
                #RENABLE-ON_COMMITTESTFAIL
                #RENABLE-ON_COMMITTESTFAIL

            else
				#echo "########## notfound"
				#echo "cmdHANDLE=\$(uci show luci | grep command | grep '.name' | grep "$CMDname" | cut -d'.' -f1,2)"
				:
			fi

			$ecmd "Adding-cmd: $CMDname $CMDbin $CMDparam $CMDpublic"

            uci -q add luci command 2>/dev/null 1>/dev/null
            uci set luci.@command[-1].name="$CMDname"
			uci set luci.@command[-1].command="$CMDbin"
			uci set luci.@command[-1].param="$CMDparam"
			uci set luci.@command[-1].public="$CMDpublic"


            #echo "$i> uci commit luci $CMDname WAIT-TILLEND-TEST" > /dev/console
            #RENABLE-ON_COMMITTESTFAIL
            #RENABLE-ON_COMMITTESTFAIL
            #RENABLE-ON_COMMITTESTFAIL
            #RENABLE-ON_COMMITTESTFAIL
            #RENABLE-ON_COMMITTESTFAIL

            #uci commit luci

            #RENABLE-ON_COMMITTESTFAIL
            #RENABLE-ON_COMMITTESTFAIL
            #RENABLE-ON_COMMITTESTFAIL
            #RENABLE-ON_COMMITTESTFAIL
            #RENABLE-ON_COMMITTESTFAIL

        ;;
	esac



    #echo "DBGeachcall $(uci changes luci)" > /dev/console





}

##commandadducimulti "rpi-support" "/bin/rpi-support.sh" "1" "1"
##commandadducimulti "add||remove" "rpi-support" "/bin/rpi-support.sh" "1" "1"








#@@@2021luci-commit-each-call-is-slow-test-changes-at-base





if opkg list-installed | grep -q '^luci-app-commands'; then

    [ -n "$DEBUG" ] && $ecmd "luci-app-commands [installed]" #$ecmd "luci-app-commands [installed]"


    ############################################################################################ ucicommandmod() {
    ############################################# OLD sh -c
	###############BACKPORTLOGIC
    #ucicommandmod "remove" "docmd"
    #if [ -x "/bin/doCMD.sh" ]; then
    #    $ecmd "command-add||readd: doCMD@/bin/doCMD.sh" #commandaddecho "doCMD" "doCMD.sh" "1" "1"
    #    ucicommandmod "add" "doCMD" "doCMD.sh" "1" "1"
    #else
    #    ucicommandmod "remove" "doCMD"
    #fi


    if [ -x "/bin/doCMD.sh" ]; then

		#NEWifbelowfunctionshouldcheckthisandreturnlineechostring
		if uci show luci | grep 'command\[' | grep '\.name' | grep -q "doCMD"; then
			$ecmd "command-leave: doCMD@/bin/doCMD.sh [ok]" #commandaddecho "doCMD" "doCMD.sh" "1" "1"
		else
			#$ecmd "command-add||readd: doCMD@/bin/doCMD.sh" #commandaddecho "doCMD" "doCMD.sh" "1" "1"
			$ecmd "command-add: doCMD@/bin/doCMD.sh" #commandaddecho "doCMD" "doCMD.sh" "1" "1"
        	ucicommandmod "add" "doCMD" "doCMD.sh" "1" "1"
		fi

	else
		$ecmd "command-remove no@/bin/doCMD.sh" #commandaddecho "doCMD" "doCMD.sh" "1" "1"
		ucicommandmod "remove" "doCMD"
    fi






    if [ -x "/bin/rpi-support.sh" ]; then
		
		if uci show luci | grep 'command\[' | grep '\.name' | grep -q "rpisupport"; then
			$ecmd "command-leave: rpisupport@/bin/rpi-support.sh [ok]"
    	else
			#$ecmd "command-readd: rpisupport@/bin/rpi-support.sh"
			$ecmd "command-add: rpisupport@/bin/rpi-support.sh"
        	ucicommandmod  "add" "rpisupport" "rpi-support.sh" "1" "1" #NOTE: this is re-adding same thing
    	fi
	
	else
        $ecmd "command-remove-nobin: rpisupport@/bin/rpi-support.sh" #EXAMPLE bin should always be there...
        ucicommandmod  "remove" "rpisupport"
    fi


    if [ -x "/bin/restorepackages.sh" ]; then
		if uci show luci | grep 'command\[' | grep '\.name' | grep -q "restorepackages"; then
			$ecmd "command-leave: restorepackages@/bin/restorepackages.sh [ok]"
		else
			$ecmd "command-add: restorepackages@/bin/restorepackages.sh"
        	ucicommandmod "add" "restorepackages" "/bin/restorepackages.sh" "1" "1"
    	fi
	else
        $ecmd "command-remove-nobin: restorepackages@/bin/restorepackages.sh"
        ucicommandmod "remove" "restorepackages"
    fi






    #$ecmd "readding temp always.. uci commit [norestart||reload_config]"
	if [ "$(uci -q changes luci 1>/dev/null 2>/dev/null | wc -l)" -gt 0 ]; then #was faulty no -gt
		$ecmd "luci-config [changes]" #uci changes luci 1>/dev/console
        uci commit luci
		##@@ $ecmd "luci-config [changes] $(uci -q changes)" #<tr -s '\n' ' ' #uci changes luci 1>/dev/console
    #else $ecmd "luci config [no-changes]"
    fi


else
    $ecmd "luci-app-commands: [not-installed]"
fi









touch /root/.firstboot.$i
exit 0












########### 2021add^already one above
#if [ "$(uci changes luci | wc -l)" -gt 0 ]; then
#    echo "$i-DBG> $(uci changes luci)" > /dev/console
#    $ecmd "changes"
#    uci commit luci 2>/dev/null 1>/dev/null
#else
#    $ecmd "no-changes"
#    uci changes luci
#fi



























############################################################################################ ucicommandmod() {
###NOTE: add removes existing = overwrite #remove
#ucicommandmod remove "docmd"
######commandadducimulti "add||remove" "rpi-support" "/bin/rpi-support.sh" "1" "1"
#ucicommandmod add "doPSwgrepXgrepvgre" "ps w | grep $1 | grep -v grep" "0" "1"
#ucicommandmod add "rpisupport" "/bin/rpi-support.sh" "1" "1"
#ucicommandmod something "doTHIS"
#exit 0
###############################################################################################################





reloadCONFIG() {


#[root@dca632 /usbstick 45°]# which reload_config /sbin/reload_config
#[root@dca632 /usbstick 45°]# cat /sbin/reload_config


cat <<'WWW'
#!/bin/sh
rm -rf /var/run/config.check
mkdir -p /var/run/config.check
for config in /etc/config/*; do
        file=${config##*/}
        uci show "${file##*/}" > /var/run/config.check/$file
done
MD5FILE=/var/run/config.md5
[ -f $MD5FILE ] && {
        for c in $(md5sum -c $MD5FILE 2>/dev/null| grep FAILED | cut -d: -f1); do
                ubus call service event "{ \"type\": \"config.change\", \"data\": { \"package\": \"$(basename $c)\" }}"
        done
}
md5sum /var/run/config.check/* > $MD5FILE
rm -rf /var/run/config.check
WWW

}












cat <<'VVV'


rule_name=$(uci add firewall rule)
uci batch << EOF
set firewall.$rule_name.enabled='1'
set firewall.$rule_name.target='ACCEPT'
set firewall.$rule_name.src='wan'
set firewall.$rule_name.proto='tcp udp'
set firewall.$rule_name.dest_port='111'
set firewall.$rule_name.name='NFS_share'
EOF
uci commit




luci.@command[0]=command
luci.@command[0].name='rpisupport'
luci.@command[0].command='rpi-support.sh'
luci.@command[0].param='1'
luci.@command[0].public='1'
luci.@command[1]=command
luci.@command[1].name='restorepackages'
luci.@command[1].command='/bin/restorepackages.sh'
luci.@command[1].param='1'
luci.@command[1].public='1'
luci.@command[2]=command
luci.@command[2].name='docmd'
luci.@command[2].command='sh -c'
luci.@command[2].param='1'
luci.@command[2].public='1'
luci.@command[3]=command
luci.@command[3].name='doCMD'
luci.@command[3].command='doCMD.sh'
luci.@command[3].param='1'
luci.@command[3].public='1'



config command
	option name 'rpisupport'
	option command 'rpi-support.sh'
	option param '1'
	option public '1'

config command
	option name 'restorepackages'
	option command '/bin/restorepackages.sh'
	option param '1'
	option public '1'

config command
	option name 'docmd'
	option command 'sh -c'
	option param '1'
	option public '1'

config command
	option name 'doCMD'
	option command 'doCMD.sh'
	option param '1'
	option public '1'

VVV






#################################################################################### ORIGINAL ECHO METHOD


if opkg list-installed | grep -q '^luci-app-commands'; then
    #$ecmd "luci-app-commands [installed]"
    [ -n "$DEBUG" ] && $ecmd "luci-app-commands [installed]"

    #commandaddecho "ifconfig" "ifconfig" "1" "1"
    #OLDONETECHNICALLYWESHOULDDELETETHIS commandaddecho "docmd" "sh -c" "1" "1"
    if [ -x "/bin/doCMD.sh" ]; then
        commandaddecho "doCMD" "doCMD.sh" "1" "1"
    fi

    commandaddecho "rpisupport" "rpi-support.sh" "1" "1"

    if [ -x "/bin/restorepackages.sh" ]; then
        commandaddecho "restorepackages" "/bin/restorepackages.sh" "1" "1"
    fi



    #commandadduci "rpi-support" "/bin/rpi-support.sh" "1" "1"
    #uci commit
    #set -x
    #commandadducimulti "rpi-support" "/bin/rpi-support.sh" "1" "1"
    #uci commit


    #$ecmd "exiting as script broken"; exit 0
    #commandadduci "ifconfigrun" "ifconfig" "1" "1"

else
    $ecmd "luci-app-commands: [not-installed]"
fi
#################################################################################### ORIGINAL ECHO METHOD
#CORRUPTS???
#its cumulative commandaddecho "ifconfigrunalltestffonemore" "ifconfig all" "1" "1"
#################################################################################### ORIGINAL ECHO METHOD












#CORRUPTS???
#its cumulative commandaddecho "ifconfigrunalltestffonemore" "ifconfig all" "1" "1"
#################################################################################### ORIGINAL ECHO METHOD









############################################################################################ ucicommandmod() {
###NOTE: add removes existing = overwrite #remove
#ucicommandmod remove "docmd"
##############################################ucicommandmod add "doCMD"
######commandadducimulti "add||remove" "rpi-support" "/bin/rpi-support.sh" "1" "1"
#ucicommandmod add "doPSwgrepXgrepvgre" "ps w | grep $1 | grep -v grep" "0" "1"
#ucicommandmod add "rpisupport" "/bin/rpi-support.sh" "1" "1"
#ucicommandmod something "doTHIS"
#exit 0
###############################################################################################################










#commandadduciOLDOLDOLD() {
#>>>!uci add luci command #uci -q add luci.command=command
#uci -q set luci.@command[-1].name='ifconfigrun'
#uci -q set luci.@command[-1].command='ifconfig'
#uci -q set luci.@command[-1].param='1'
#uci -q set luci.@command[-1].public='1'
#}
#commandadducimultiOLDOLDOLDOLD() {
#>>>!uci add luci command #uci -q add luci.command=command
#uci -q set luci.@command[-1].name="$1"
#GOODISH uci -q set luci.command="$1"
#}
















#uci show luci | grep '^luci.@command'
###########################################################
#nothing() {
###########################################################
#luci.@command[0]=command
#luci.@command[0].name='ifconfigrun'
#luci.@command[0].command='ifconfig'
#luci.@command[0].param='1'
#luci.@command[0].public='1'
###########################################################
#config command
#	option name 'ifconfigrun'
#	option command 'ifconfig'
#	option param '1'
#	option public '1'
###########################################################
#uci -q set luci.command[0]=command
#luci.@command[0].name='ifconfigrun'
#luci.@command[0].command='ifconfig'
#luci.@command[0].param='1'
#luci.@command[0].public='1'
#########################################


############################################################
#config command
#        option command 'tc -s qdisc show dev eth0'
#        option name 'qdisc stats egress'

#config command
#        option command 'tc -s qdisc show dev ifb4eth0'
#        option name 'qdisc stats ingress'
###########################################################
#}












