#!/bin/sh

#uuidgen





#optional: /bin/mountcmd.sh; chmod +x and add to sysupgrade.conf for persistent (smb/sshfs) mounting
#mount -t cifs -o username=x,password=x,uid=1000,forceuid,forcegid //10.2.3.6/downloads /usbstick/downloads/


	
#LIMIT_BW
#YD_OPTS="${YD_OPTS} -r 1550K"




###HACKFORdl.php
touch /tmp/dllog.txt 2>/dev/null
touch /tmp/.$(basename $0).history 2>/dev/null

#? queue aka hash andorurl until ^ history
queuetxt="/tmp/.$(basename $0).queue"
touch /tmp/.$(basename $0).queue 2>/dev/null







#top -b -n1 | grep -v grep | grep '/usr/bin/python3 /usr/bin/youtube-dl' | tr -s '\t' ' ' | cut -d' ' -f11-












#IB 67M>71M@regen ytdl







################################## PHP
#ln -s /usbstick/downloads/ /www/downloads
######### // 240 max_execution_time = 30	; Maximum execution time of each script, in seconds






############################################################################################
#mount -t cifs -o username=x,password=x,uid=1000,forceuid,forcegid //10.2.3.6/downloads /usbstick/downloads/
########################NOPE mount -t cifs -o username=x,password=x //10.2.3.6/downloads /usbstick/downloads
#######################awk '$3 ~ /cifs/ {print $4}' /etc/fstab|sed 's|'$(whoami)'|username|g'
########################awk '$3 ~ /cifs/ {print $4}' /proc/mounts
##########################[global]
#############################min protocol = SMB2
############################################################################################
#curl -I -L 
#ContentLength
############################################################################################





historytxt="/tmp/.dl.sh.history"

if [ "${1}" = "printhistory" ]; then

	#historytxt="/tmp/.dl.sh.history"
	#cat $historytxt 2>/dev/null | grep -v 'pass \-k to keep' | grep -v 'Extracting information' | cut -d'[' -f2 | tr -s ']' ' '
	cat $historytxt 2>/dev/null | grep -v 'pass \-k to keep' | grep -v 'Extracting information' | cut -d'[' -f2 | tr -s ']' ' ' | sort -r

	exit 0
fi



#stdoud="/tmp/.dl.sh.stoud"
#cat $stdoud 2>/dev/null | grep -v 'pass \-k to keep' | grep -v 'Extracting information' | cut -d'[' -f2 | tr -s ']' ' '
##$outputt = shell_exec("tail -c90 $stdoud 2>/dev/null | grep -v 'pass \-k to keep' | grep -v 'Extracting information' | cut -d'[' -f2 | tr -s ']' ' '");
#tail -c90 $stdoud 2>/dev/null | grep -v 'pass \-k to keep' | grep -v 'Extracting information' | cut -d'[' -f2 | tr -s ']' ' '


















YD=$(command -v youtube-dl)
CURL=$(command -v curl)








#YOUTUBEDL="/usbstick/downloads"
eval $(grep '^YOUTUBEDL=' /root/wrt.ini 2>/dev/null)
#@~~~ eval $(grep '^YOUTUBEDLmnt?=' /root/wrt.ini 2>/dev/null)







dirDATAmnt="/usbstick" #dirDATAmnt="/usbWRONG"



dirDATA="${dirDATAmnt}/downloads" #FILEWITHSAMENAMETHERE!!! dirDATA="/usbstick/$(basename $0)"
#dirVIDEOin="/in"









DRIVE_FREE_BYTES_MIN="662004" #DRIVE_MIN_FREE_BYTES="9000000" #9G #DRIVE_MIN_FREE_BYTES="662004" #650M
DRIVE_PERCENT_USED_MAX="91"





#NOTUSEDYET~stdout|err
TMPd="/tmp/$(basename $0)"; mkdir -p $TMPd
































#SKIPMEPLEASE() {
if [ ! -f /root/.$(basename $0).prereq ]; then

	if grep -q "^max_execution_time 30$" /etc/php.ini; then
		sed -i "s!max_execution_time = 30!max_execution_time = 125!g" /etc/php.ini
	fi #if [ ! -f /etc/php.ini ]; then



	echo "checking prerequisites: youtube-dl curl ffmpeg... "
	if [ -z "$YD" ]; then
		PKGINST="${PKGINST} youtube-dl"
	else
		PKGOK="${PKGOK} youtube-dl"
	fi
	#echo "installing youtube-dl..."; opkg install youtube-dl
	if [ -z "$CURL" ]; then #echo "installing curl... "; opkg install curl
		PKGINST="${PKGINST} curl"
	else
		PKGOK="${PKGOK} curl"
	fi


	FFMPEG="$(command -v ffmpeg)"
	if [ ! -z "$FFMPEG" ]; then
		:
	elif [ -z "$FFMPEG" ] && [ -f /bin/ffmpeg-aarch64 ]; then #@? ! -f /usr/bin/ffmpeg
		echo "install ffmpeg... "
		/bin/ffmpeg-aarch64 #checkretval-needs-nonaarch
	else
		echo "cannot install ffmpeg"; exit 1
	fi
	if [ -z "$(command -v ffmpeg)" ]; then
		echo "ffmpeg-failed"; exit 1
	else
		PKGOK="${PKGOK} ffmpeg"
	fi

	if [ ! -z "${PKGINST}" ]; then

		if [ ! -f /tmp/.$(basename $0).opkgupd ]; then
			echo "update opkg..."; opkg update 1>/dev/null 2>/dev/null || exit 1
		fi

		echo "installing ${PKGINST}..."; opkg install ${PKGINST} 1>/dev/null 2>/dev/null || exit 1
		touch /tmp/.$(basename $0).opkgupd
	else
		echo "all packages ok: $PKGOK"
	fi

	touch /root/.$(basename $0).prereq
fi
#apt install youtube-dl
#}







#echo "TOPEXIT"
#exit 0























fails() {
    echo "$1" && exit 1
}







sanitizename() {
	echo "${1}" | \
		sed 's! !_!g' | \
		sed "s!'!!g" | \
		tr -s ',' '_' | \
		tr -s '[' '$' | tr -s ']' '$' | tr -s '(' '$' | \
		tr -s ')' '$' | \
		sed 's!\$!!g'

}









getsize() {

    local gotsize=
	#if [ ! -d "$1" ]; then echo "nodir: $1"; return 3; fi
	case "$2" in
		bytes)
            		#gotsize=$(du -cs $1/* 2>/dev/null | tail -n 1 | tr -s '\t' ' ' | cut -d' ' -f1)
            		du -cs $1/* 2>/dev/null | tail -n 1 | tr -s '\t' ' ' | cut -d' ' -f1
		;;
		filesize)
            		#gotsize=$(du -cs $1/* 2>/dev/null | tail -n 1 | tr -s '\t' ' ' | cut -d' ' -f1)
            		#echo "du -chs \"${1}\" 2>/dev/null | tail -n 1 | tr -s '\t' ' ' | cut -d' ' -f1"
            		#du -ch "${1}" 2>/dev/null | tail -n 1 | tr -s '\t' ' ' | cut -d' ' -f1
            		#du -ch "${1}" 2>/dev/null | tail -n 1

			ls -lah "${1}" | tr -s '\t' ' ' | cut -d' ' -f5
		;;
		drivepercentused)
			df | tr -s '\t' ' ' | grep "${1}$" | cut -d' ' -f5
		;;
		drivebytesfree)
			df | tr -s '\t' ' ' | grep "${1}$" | cut -d' ' -f4
		;;

        	*)
            		#gotsize=$(du -chs $1/* 2>/dev/null | tail -n 1 | tr -s '\t' ' ' | cut -d' ' -f1)
            		du -chs $1/* 2>/dev/null | tail -n 1 | tr -s '\t' ' ' | cut -d' ' -f1
        	;;
    esac
    #if [ -z "$gotsize" ]; then echo 0; else echo "$gotsize"; fi
    return 0
}








usage() {
cat <<EOG

	$0 [-v|-D] -Y [-I] [-A|-A2|-AV] [-U <user>] [-W] -url <url> 

		-Y			[youtube]
			-I		[get info with -Y all dlfiles]

		-A(sound)		[get audio>mp3]
		-AV(clip)		[get audio-clip]
		-A2(soundandclip)	[get both mp3+clip]

		-url <http>
		-bwlimit		[limitbandwidth]
		-D			enable debugging
		-v			verbose(do not use with -W)

		-P status
		
		-W			webserver call(no output)
		-bwlimit		hardcoded 1.5Mb/s dl limit


	$0 -Y -url https://www.youtube.com/watch?v=QozGSS7QY_U
	$0 -Y -I -url https://www.youtube.com/watch?v=QozGSS7QY_U
	$0 -U some -Y -A2 -url https://www.youtube.com/watch?v=PBsjggc5jHM
EOG
}
#$0 [-R] [stable|current|testing|20.1] [check|downgrade|force] [-v]
#-FL			dump recent faillogs
#-x          obtain live manifestetc
#-M			show mirror versions













msgout() {


	#TMPHACK
	if [ -n "$DEBUG" ]; then
		echo "$0 [ALLCONSOLEDBG${2:-"meh"}] ${1}" > /dev/console
	fi



	case "${2}" in
		debug)
			#[ ! -z "$DEBUG" ] && echo "$I-$D> ${1}" >/dev/console
			[ ! -z "$DEBUG" ] && echo "$I-$D> ${1}"
			return 0
		;;
		verbose)
			[ ! -z "$VERBOSE" ] && echo "$I-$V> ${1}" && return 0
			[ ! -z "$DEBUG" ] && echo "$I-$D> ${1}" && return 0
		;;
		*)
			echo "$I> ${1}" && return 0
		;;
	esac

}





#if [ ! -z "$TESTING" ]; then
#	echo "[${2:-"noparam2"}] ${1}" >> "${Ilog:-"/tmp/$(basename $0).msgs"}" #ALLTO-Ilog
#fi
#############HACK FOR CMDLINE 'luci' > echo stdout #if [ ! -z "$SSH_CONNECTION" ]; then
##############echo "$I-$D-lucicmdlinefake> ${1}"








#set -x




ALLPARAMS=${*}










while [ "$#" -gt 0 ]; do
case "${1}" in
	help|-h|--help) usage; exit 0; ;;
	"-v") VERBOSE=1; shift 1; ;;
	"-D") DEBUG=1; shift 1; ;;
	
	
	"-P") DOSTATUS=1; shift 1; ;;

	"-B") BGCALL=1; shift 1; ;;
	"-W") ISWWW=1; shift 1; ;;



	"-bwlimit") LIMIT_BW=1; shift 1; ;;
	#########################################################
	

	"-U")   shift 1
		USERpfx=${1}
		shift 1
	;;


	"-Y") DO_YOUTUBE=1; shift 1; ;;

	"-A2")
		YT_GETAUDIOBOTH=1
		shift 1
	;;




	"-A")
		YT_GETAUDIO=1
		shift 1
	;;
	"-AV")
		YT_GETMUSICCLIP=1
		shift 1
	;; #same as video just outputs to alt dir seperate history
	

	"-I")
		YT_GETINFO=1
		CURL_GETINFO=1
		shift 1
	;;

	"-url")
		shift 1
		URL_DL=${1}
		shift 1
	;;
	"-x") RMTMPCACHE=1; shift 1; ;;
	"-FL") SHOWFAIL=1; shift 1; ;;
	force) FORCE="force"; shift 1; ;;

	

	"-M") SHOWMIRROR=1; shift 1; ;;
	


	#downgrade) DG="downgrade"; shift 1; ;;
	#"-R") Rpkg="-R"; shift 1; ;;
	#check) DOCHECK="check"; shift 1; ;;
	#current|stable|testing) FLAVOUR="${1}"; shift 1; ;; #@ifzFLAV
	


	*) echo "unknown-parameter: $1"; usage; shift 1; sleep 1; exit 0; ;;
esac
done



#set -x










#set -x









################################### hardcoding this on
#LIMIT_BW=1




USERpfx=${USERpfx:-"unknown"}
I="$(basename $0)" #@msgout






case "$(cat /proc/$PPID/cmdline)" in
	"/sbin/procd")
		NONINTERACTIVE=1
		echo "PROCDCMD: $0 ${ALLPARAMS}" > /dev/console
	;;
	"/bin/bash")
		echo "USERCMD: $0 ${ALLPARAMS}" > /dev/console
	;;
esac






if [ ! -z "$BGCALL" ]; then
	CLEANPARAMS=$(echo $ALLPARAMS | sed 's!-B !!g')
	#echo "BGCALL RUN: ($0 $CLEANPARAMS)&"; sleep 2
	msgout "MSGOUT-fixNONINTERACTIVEconsole-debug> BGCALL RUN: ($0 $CLEANPARAMS)&" debug
	($0 $CLEANPARAMS 1>>/tmp/dllog.txt)&
	exit 0
fi








if ! mount | grep -q " ${dirDATAmnt} "; then ISSUES="${ISSUES} datam:$dirDATAmnt [notmountpoint]"; fi
if ! mount | cut -d ' ' -f3 | grep -q "^$dirDATAmnt$"; then ISSUES="${ISSUES} datam:$dirDATAmnt [nope]"; fi

if [ ! -z "$ISSUES" ]; then echo "setup-issues: $ISSUES"; exit 0; fi #exit 0







diskDATAmnt=$(mount | grep " ${dirDATAmnt} " | cut -d' ' -f1)
DRIVE_FREE_BYTES=$(getsize "${dirDATAmnt}" drivebytesfree)
DRIVE_PERCENT_USED=$(getsize "${dirDATAmnt}" drivepercentused | sed 's!%!!g')










######################################DUMMYVALS
#DRIVE_FREE_BYTES_MIN="9000000" #9G
#DRIVE_PERCENT_USED_MAX="50"
######################################DUMMYVALS






if [ "$DRIVE_FREE_BYTES" -lt "$DRIVE_FREE_BYTES_MIN" ]; then
	ISSUES="${ISSUES} DRIVEMAXBYTES $dirDATAmnt $diskDATAmnt"
fi
if [ "$DRIVE_PERCENT_USED" -gt "$DRIVE_PERCENT_USED_MAX" ]; then
	ISSUES="${ISSUES} DRIVEPERCENTOVER ${DRIVE_PERCENT_USED}% [max:${DRIVE_PERCENT_USED_MAX}%]"
fi



if [ ! -z "$ISSUES" ]; then echo "setup-issues: $ISSUES"; exit 0; fi #exit 0







#msgout "DRIVE:${dirDATAmnt} used:${DRIVE_PERCENT_USED}% freebytes:$DRIVE_FREE_BYTES" verbose
#set -x







msgout "DRIVE:${dirDATAmnt} used:${DRIVE_PERCENT_USED}% freebytes:$DRIVE_FREE_BYTES" verbose
mkdir -p $dirDATA

















ytdownload() {







	local FN="ytdownload"
	local INURL="${2}"
	local MVDIR="${3}"
	#YTmetaD="$dirDATA/youtube/.meta"; mkdir -p $YTmetaD
	#local YThistory="$YTmetaD/history"
	local YThistory="$MVDIR/.history"



case "${1}" in
	get)
		msgout "$FN> $YD $YD_OPTS $INURL" verbose #echo "$FN> $YD $YD_OPTS $INURL"; sleep 2

		if grep -wq "$INURL" "${YThistory}" 2>/dev/null; then
			echo "already downloaded: $(grep $INURL ${YThistory})"; return 0
		fi

		#cd $dirVIDEOin || return 1 #cd /usbstick/downloads/youtube/in/some TECHNICALLY'cache'
		#cd $dirVIDEOin || return 1 #cd /usbstick/downloads/youtube/in/some TECHNICALLY'cache'
	
		if touch test 2>/dev/null; then
			rm test
		else
			echo "$(pwd) not writable"; return 1
		fi



		rm /tmp/.$(basename $0).stoud 2>/dev/null; rm /tmp/.$(basename $0).sterr 2>/dev/null


		#echo "DBGSTDVIDEO: $YD $YD_OPTS ${INURL}"
		#echo "PWD: $(pwd)"
		#sleep 2


		#may need '-f best' here etc @'mergingnotice'



	#NOWINMAIN-APPENDEDtoINBOUND
	#DLHASHu=$(uuidgen | cut -d'-' -f5)





	#queuetxt="/tmp/.$(basename $0).queue"
	echo "$(date +%Y%m%d%H%M%S) ${DLHASHu} ${INURL}" >> $queuetxt






	#$YD $YD_OPTS ${INURL} 1>/tmp/.$(basename $0).stoud 2>/tmp/$(basename $0).stderr && local CMDOK=1
	$YD $YD_OPTS ${INURL} 1>/tmp/.$(basename $0).stoud 2>/tmp/.$(basename $0).stderr && local CMDOK=1
	#$YD $YD_OPTS ${INURL} && local CMDOK=1
	ydRETVAL=$?
	msgout "ydRET: $ydRETVAL" verbose



	#if [ "$ydRETVAL" -ne 0 ]; then
	#	echo "download-failed"
	#	if [ -f /tmp/.$(basename $0).stoud ]; then
	#		echo "oops############ stdout"; cat /tmp/.$(basename $0).stoud 2>/dev/null
	#	fi
	#	if [ -f /tmp/.$(basename $0).sterr ]; then
	#		echo "oops############ stderr"; cat /tmp/$(basename $0).stderr 2>/dev/null
	#	fi
	#	return 5
	#fi




	#INFILE="$(ls -1 . | grep -E '(mkv|webm|mp3|mp4|m4a)'"
	INFILE="$(ls -1 . | grep -vE '(part$|ytdl$)')"


	#INFILE_HASH="$(echo $INFILE | sed 's!.mp4!!g')"
	INFILE_HASH="$(cat /tmp/.$(basename $0).stoud | grep 'Downloading webpage' | cut -d' ' -f2 | sed 's! !!g' | sed 's!:!!g')"


	if [ ! -z "$CMDOK" ]; then
		echo "${INURL} \"${INFILE_HASH}\" \"${INFILE}\"" >> "${YThistory}"
	else
		echo "FAILED! $YD $YD_OPTS ${INURL}"
		if [ -f /tmp/.$(basename $0).stoud ]; then
			echo "oops############ stdout"; cat /tmp/.$(basename $0).stoud 2>/dev/null
		fi
		if [ -f /tmp/.$(basename $0).sterr ]; then
			echo "oops############ stderr"; cat /tmp/.$(basename $0).stderr 2>/dev/null
		fi
		#cd $HERE
		#@@@IFRUNSILENT
		echo "1removing stdoud stderr for www tidy" >/dev/console
		rm /tmp/.$(basename $0).stoud 2>/dev/null
		rm /tmp/.$(basename $0).stderr 2>/dev/null
		
		return 1
	fi







	case "$INFILE" in
		*".m4a")
			FILE_EXT=".m4a"
		;;
		*".mkv")
			FILE_EXT=".mkv"
		;;
		*".mp4")
			FILE_EXT=".mp4"
		;;
		*".webm")
			FILE_EXT=".webm"
		;;
		*)
			echo "UNKNOWNEXTENTION: $INFILE"; sleep 3
		;;
	esac




	NEWNAME="$(sanitizename "${INFILE}")"
	#echo "INFILE: $INFILE $INFILE_HASH ${NEWNAME}"
	msgout "INFILE: $INFILE $INFILE_HASH ${NEWNAME}" verbose
	
	msgout "mv ${INFILE} ${MVDIR}/${NEWNAME}" verbose
	mv "${INFILE}" "${MVDIR}/${NEWNAME}"
	
	#NOPEjustSLOWecho "${MVDIR}/${NEWNAME}" >> ${historytxt}



if [ ! -z "$VERBOSE" ]; then
	cat <<PPP
      INFILE: $INFILE
 INFILE_HASH: $INFILE_HASH
     NEWNAME: $NEWNAME
    FILE_EXT: $FILE_EXT
     MOVEDTO: ${MVDIR}/${NEWNAME}


PPP
sleep 5
fi






	if [ ! -z "$YT_GETAUDIO" ] && [ ! -z "$FFMPEG" ]; then
	
		#NEWNAMEnoext="$(echo "${NEWNAME}" | sed 's!\.webm!!g')"
		#NEWNAMEnoext="$(echo "${NEWNAME}" | sed "s!\.m4a!!g")"
		NEWNAMEnoext="$(echo "${NEWNAME}" | sed "s!${FILE_EXT}!!g")"

		#ffmpeg -i "${MVDIR}/${NEWNAME}" -b:a 320K -vn "${MVDIR}/${NEWNAME}".mp3
if [ ! -z "$VERBOSE" ]; then
		ffmpeg -i "${MVDIR}/${NEWNAME}" -b:a 320K -vn "${MVDIR}/${NEWNAME}".mp3
else
		ffmpeg -i "${MVDIR}/${NEWNAME}" -b:a 320K -vn "${MVDIR}/${NEWNAMEnoext}".mp3 1>/dev/null 2>/dev/null

fi
		RETVAL=$?
		msgout "audioRET: $RETVAL" verbose
		FINALFILE="${MVDIR}/${NEWNAMEnoext}.mp3"



		if [ ! -z "$KEEPORIGINAL" ]; then #&&convertok
			mkdir -p "${MVDIR}/original"
			msgout "mv ${MVDIR}/${NEWNAME} ${MVDIR}/original/" verbose
			mv "${MVDIR}/${NEWNAME}" "${MVDIR}/original/"
		else
			#echo "audioRET: $RETVAL > rm ${MVDIR}/${NEWNAME}"
			#echo "rm ${MVDIR}/${NEWNAME}"
			msgout "RMPRECONVERTED rm ${MVDIR}/${NEWNAME}" verbose
			rm "${MVDIR}/${NEWNAME}"
		fi
	else
		FINALFILE="${MVDIR}/${NEWNAME}" #DONEABOVE mv "${INFILE}" "${MVDIR}/${NEWNAME}"
	fi #rm "${MVDIR}/${NEWNAME}"










	#cd $HERE
	#)







	;; #eng get

	
	info)
	$YD -F ${INURL} 1>/tmp/.$(basename $0).stoud 2>/tmp/.$(basename $0).stderr && local CMDOK=1
	if [ ! -z "$CMDOK" ]; then
		cat /tmp/.$(basename $0).stoud
		return 0
	else
		echo "oops $YD -F ${INURL} ############ stdout"
		cat /tmp/.$(basename $0).stoud 2>/dev/null
		echo "oops $YD -F ${INURL} ############ stderr"
		cat /tmp/.$(basename $0).stderr 2>/dev/null
		echo "2removing stdoud stderr for www tidy" >/dev/console
		
		#@@@losing file lines neverhit this yet too
		#rm /tmp/.$(basename $0).stoud 2>/dev/null
		#rm /tmp/.$(basename $0).stderr 2>/dev/null
		return 1
	fi

	;;

	*)
		echo "unknown cmd ${1}" >&2
		return 1
	;;

esac


#if [ ! -z "$ISWWW" ]; then
#	echo "<p>$FINALFILE</p>" #echo "finalfile: $FINALFILE"
#else








	#MP3ONLYNOPEJUSTDLOW

	echo "$FINALFILE" #echo "finalfile: $FINALFILE"
	
	


	#echo "$FINALFILE" >> ${historytxt}
	###########echo "$(date +%Y%m%d%H%M%S) ${DLHASHu} ${INURL}" >> $queuetxt
	###########echo "
	echo "$(date +%Y%m%d%H%M%S) $FINALFILE" >> ${historytxt}
#fi




	#sed -i "|${INURL}|d" $queuetxt
	#echo "sed -i \"|^${DLHASHu}|d\" $queuetxt" >/dev/console
	#sed -i "|^${DLHASHu}|d" $queuetxt
	

	#sed -i "/^${DLHASHu}/d" $queuetxt
	sed -i "/ ${DLHASHu} /d" $queuetxt 2>/dev/null






	#@@@losing file lines and never hit this
	#echo "3removing stdoud stderr for www tidy bottomfunc" >/dev/console
	#rm /tmp/.$(basename $0).stoud 2>/dev/null
	#rm /tmp/.$(basename $0).stderr 2>/dev/null

}











#OUTPUTNAME youtube-dl -o 'abdul kalam inspirational speech' https://www.youtube.com/watch?v=7E-cwdnsiow
#NAME+PATH youtube-dl -o '~/Downloads/abdul kalam speech' https://www.youtube.com/watch?v=7E-cwdnsiow
#SPECIALNAMEPATHVARS
#youtube-dl -o '%(title)s by %(uploader)s on %(upload_date)s in %(playlist)s.%(ext)s' https://www.youtube.com/watch?v=7E-cwdnsiow


#urlsintextfile youtube-dl -a url.txt
#audioonly youtube-dl -x https://www.youtube.com/watch?v=7E-cwdnsiow
#youtube-dl -x --audio-format mp3 https://www.youtube.com/watch?v=7E-cwdnsiow


###get metadata and stuff
#youtube-dl --write-description --write-info-json --write-annotations --write-sub --write-thumbnail https://www.youtube.com/watch?v=7E-cwdnsiow


###################### dump url info formats/size
#youtube-dl --list-formats https://www.youtube.com/watch?v=7E-cwdnsiow
#OR youtube-dl -F https://www.youtube.com/watch?v=7E-cwdnsiow


#$ youtube-dl -f best https://www.youtube.com/watch?v=7E-cwdnsiow
#Similarly, to download audio-only with best quality:

#$ youtube-dl -f bestaudio https://www.youtube.com/watch?v=7E-cwdnsiow
#To download worst quality video-only format, use the following command:

#$ youtube-dl -f worstvideo https://www.youtube.com/watch?v=7E-cwdnsiow

#You also combine different format options like below.
#$ youtube-dl -f bestvideo+bestaudio https://www.youtube.com/watch?v=7E-cwdnsiow
#The above command will download best quality video-only and best quality audio-only formats and merge them together with ffmpeg or avconv. Make sure you have installed any one of these tools on your system.

#If you don't want to merge, replace +(plus) operator with ,(comma) like below:
#$ youtube-dl -f 'bestvideo,bestaudio' https://www.youtube.com/watch?v=7E-cwdnsiow -o '%(title)s.f%(format_id)s.%(ext)s'



#$ youtube-dl -f "best[height<=480]" https://www.youtube.com/watch?v=7E-cwdnsiow
#$ youtube-dl -f "best[height<=480]" https://www.youtube.com/watch?v=7E-cwdnsiow
#$ youtube-dl -f 'bestvideo[height<=480]+bestaudio/best[height<=480]' https://www.youtube.com/watch?v=7E-cwdnsiow
#$ youtube-dl --list-formats https://www.youtube.com/watch?v=7E-cwdnsiow








dlstatus() {


#echo "FIXMEHARDCODED INBOUND (needsINBOUNDp)/usbstick/downloads/inbound/x/x/.part" >/dev/console
###############dirDATA="${dirDATAmnt}/downloads" #FILEWITHSAMENAMETHERE!!! dirDATA="/usbstick/$(basename $0)"
#echo "find $dirDATA/inbound/*/*.part 2>/dev/null | grep -v '\-Frag'" >/dev/console



find $dirDATA/inbound/*/*.part 2>/dev/null | grep -v '\-Frag' | while read dlfile; do


	echo "DBGdlfile: $dlfile" >/dev/console #/usbstick/downloads/inbound/8dd40224b722/
	


	#@@@sed rm $dirDATA/inbound?
	HFIND=$(echo $dlfile | cut -d'/' -f5)
	echo "HFIND: $HFIND" >/dev/console

	dlfileP=$(echo $dlfile | sed 's!.part!!g')
	dlfileS=$(getsize "$dlfile" filesize)
	echo "$HFIND $dlfileP $dlfileS"
done





}



################################################### NOPE string w non filename on end
#DLGOTDIR=$(dirname $dlfile)
#echo "DLGOTDIR: $DLGOTDIR" >/dev/console
#HFIND=$(basename $DLGOTDIR)
#echo "HFIND: $HFIND" >/dev/console
######
#NOPE HFIND=$(basename $(echo $(dirname $dlfile)))
#########################################################

###########################################################################################
#find $dirDATA/inbound/*/*.part 2>/dev/null | grep -v '\-Frag' | while read dlfile; do
#	dlfileP=$(echo $dlfile | sed 's!.part!!g')
#	dlfileS=$(getsize "$dlfile" filesize)
#	echo "$dlfileP $dlfileS"
#done
##########################################################################################








#find /usbstick/downloads/inbound/*.part 2>/dev/null | grep -v '\-Frag' | while read dlfile; do



#echo $(getsize "$(find /usbstick/downloads/inbound/*.part 2>/dev/null)" filesize)
#ls -lah "/usbstick/downloads/inbound/American Experience S24E13 Silicon Valley 720p HDTV x264 PBS-3AtcFHIY4Pw.f298.mp4.part" | tr -s '\t' ' ' | cut -d' ' -f5
#echo "##########files"
#find /usbstick/downloads/inbound/*.part 2>/dev/null | sed 's!.part!!g'







#echo "$(getsize "$(find /usbstick/downloads/inbound/*.part)" bytes)"
#$(getsize "$(find /usbstick/downloads/inbound/*.part)" bytes)

#echo "$(getsize "$(find /usbstick/downloads/inbound/*.part)" bytes)"

#/usbstick/downloads/inbound/Timothy McVeigh Best Documentary 2017 Oklahoma City PBS American Experience   2017 Documentary-LTclrqwxfhg.f247.webm



#tail -c90 /tmp/.$(basename $0).stdoud 2>/dev/null | cut -d'[' -f2 | tr -s ']' ' '
#tail -c90 /tmp/.$(basename $0).stdoud 2>/dev/null
#tail -n2 /tmp/.$(basename $0).stdoud 2>/dev/null



























if [ ! -z "$DOSTATUS" ]; then



	#dlstatus


	QCOUNT=$(cat $queuetxt 2>/dev/null | wc -l)

	if [ "$QCOUNT" -gt 0 ]; then
		echo "############ queue [$QCOUNT]"

		cat $queuetxt 2>/dev/null | sort -r | while read PROGr; do
			HGET=$(echo "$PROGr" | cut -d' ' -f2)
			#echo "$PROGr $(dlstatus | grep "$HGET")"
			#echo "DBGFULLSTATUS $(dlstatus)" >/dev/console

			STATLINE=$(dlstatus | grep "$HGET" | cut -d'/' -f6)

			#echo "TTT $PROGr $STATLINE" > /dev/console
			echo "$PROGr $STATLINE"
		

		done
		#top -b -n1 | grep -v grep | grep '/usr/bin/python3 /usr/bin/youtube-dl' | tr -s '\t' ' ' | cut -d' ' -f11-
	else
		echo "############ queue [empty]"
	fi



	exit 0
fi



if [ -z "$DO_YOUTUBE" ]; then #NOPE if [ -z "$DO_YOUTUBE" ] || [ -z "$DOSTATUS" ]; then
	echo "# must specify one of -Y or ..."; #sleep 3
	usage
	exit 0
fi












echo "CMDLINEdd: $(cat /proc/$$/cmdline)" > /dev/console
echo "CMDLINEPPID: $(cat /proc/$PPID/cmdline)" > /dev/console
##############################
#CMDLINEdd: /bin/sh./dl.sh-Usome-Y-urlhttps://www.youtube.com/watch?v=9FaOKNpAiIM
#CMDLINEPPID: /bin/bash
############################## luci
#CMDLINEdd: /bin/sh/bin/dl.sh-W-Uword-Y-urlhttps://www.youtube.com/watch?v=9FaOKNpAiIM
#CMDLINEPPID: /sbin/procd

############################
#CMDLINEdd: /bin/sh/bin/dl.sh-W-Uword-Y-urlhttps://www.youtube.com/watch?v=krfcq5pF8u8
#CMDLINEPPID: /usr/bin/php-cgi/www/dl/dl.php











if [ -z "$URL_DL" ] || ! echo "$URL_DL" | grep -q '^http'; then
	ISSUES="${ISSUES} url: $URL_DL [issue]"
fi #fails ""?
if [ ! -z "$ISSUES" ]; then echo "$ISSUES"; exit 0; fi





FFMPEG="$(command -v ffmpeg)"

if [ -z "$FFMPEG" ]; then msgout "ffmpeg [issue]" verbose; fi













#set -x



dirVIDEO="$dirDATA/youtube/video/${USERpfx}"; mkdir -p $dirVIDEO
dirAUDIO="$dirDATA/music-mp3/$USERpfx"; mkdir -p $dirAUDIO
dirAUDIOCLIP="$dirDATA/music-video/${USERpfx}"; mkdir -p $dirAUDIO
###INCORRECT
dirVIDEOin="$dirDATA/youtube/in/${USERpfx}"; mkdir -p $dirVIDEOin
YTmetaD="$dirDATA/youtube/${USERpfx}/.meta"; mkdir -p $YTmetaD













dumpdebug() {
cat <<LLL
dirVIDEO="$dirDATA/youtube/video"; mkdir -p $dirVIDEO
dirAUDIO="$dirDATA/music-mp3/$USERpfx"; mkdir -p $dirAUDIO
dirAUDIOCLIP="$dirDATA/music-video/$USERpfx"; mkdir -p $dirAUDIO
dirVIDEOin="$dirDATA/youtube/in/$USERpfx"; mkdir -p $dirVIDEOin
YTmetaD="$dirDATA/youtube/${USERpfx}/.meta"; mkdir -p $YTmetaD
LIMIT_BW $LIMIT_BW
username: $USERpfx
LLL
}



if [ -n "$DEBUG" ]; then dumpdebug > /dev/console; fi









#msgout "username: $USERpfx" verbose #exit 0


#echo "WOOEXIT" >/dev/console; exit 0















if [ ! -z "$DO_YOUTUBE" ] && [ ! -z "$YT_GETAUDIOBOTH" ]; then
	#thiswillbreaknamegets ls -1 DLDIR > DLUUIDx
	($0 -U ${USERpfx} -Y -A -url ${URL_DL}) &
	($0 -U ${USERpfx} -Y -AV -url ${URL_DL}) &
	exit 0
fi
#$0 -U ${USERpfx} -Y -A -url ${URL_DL}
#$0 -U ${USERpfx} -Y -AV -url ${URL_DL}















if [ ! -z "$DO_YOUTUBE" ]; then


	if [ ! -z "$LIMIT_BW" ]; then YD_OPTS="${YD_OPTS} -r 1550K"; fi


	if [ ! -z "$YT_GETAUDIO" ]; then
		YD_OPTS="${YD_OPTS} -f bestaudio "
		#@NEEDTOCONVERTWHATEVER YD_OPTS="${YD_OPTS} -f bestaudio --audio-format mp3"

		DIROUT="${dirAUDIO}"
	fi #youtube-dl -f bestaudio https://www.youtube.com/watch?v=7E-cwdnsiow



	if [ ! -z "$YT_GETMUSICCLIP" ]; then
		DIROUT="${dirAUDIOCLIP}"
	fi






	#if [ ! -z "$YT_GETINFO" ]; then YD_OPTS="${YD_OPTS} -F "; fi
	if [ ! -z "$YT_GETINFO" ]; then
		ytdownload info "$URL_DL"
		exit $?
	fi

	



	DIROUT="${DIROUT:-"$dirVIDEO"}"; mkdir -p $DIROUT
	msgout "dirout: $DIROUT" verbose



	HERE=$(pwd)
	#cd $dirVIDEOin
	





	#DIRINBOUND="${dirDATA}/inbound"; mkdir -p $DIRINBOUND
	

	DLHASHu=$(uuidgen | cut -d'-' -f5)
	DIRINBOUND="${dirDATA}/inbound/${DLHASHu}"; mkdir -p $DIRINBOUND
	

	rm -rf "$DIRINBOUND"/* 2>/dev/null #STALECACHEBREAKSls-1
	cd "${DIRINBOUND}" || fails "inboundnope: $DIRINBOUND"




	#echo "SPAWM: $YD $YD_OPTS $INURL"




	if [ ! -z "$VERBOSE" ]; then
		V_SZh="$(getsize "${DIROUT}")"
		V_SZb="$(getsize "${DIROUT}" bytes)" #V_SZb="$(getsize bytes "${dirVIDEO}")"
		echo "dirsizepre: $(basename $DIROUT) ${V_SZh}[${V_SZb}]"
	fi
	




	#echo "$YD $YD_OPTS $URL_DL"; #sleep 3 #exit 0 #$YD $YD_OPTS $URL_DL
	###################ytdownload get "$URL_DL" "${dirVIDEO}"
	ytdownload get "$URL_DL" "${DIROUT:-"$dirVIDEO"}"



	if [ ! -z "$VERBOSE" ]; then
		V_SZh="$(getsize "${DIROUT}")"
		V_SZb="$(getsize "${DIROUT}" bytes)" #V_SZb="$(getsize bytes "${dirVIDEO}")"
		echo "dirsizepost: $(basename $DIROUT) ${V_SZh}[${V_SZb}]"
	fi




	cd $HERE

fi
















exit 0 #echo "################################### bottom"


















#THEBASEBITS

	


	if [ -z "$FFMPEG" ] && [ -f /bin/ffmpeg-aarch64 ]; then #@? ! -f /usr/bin/ffmpeg
		echo "install ffmpeg... "
		/bin/ffmpeg-aarch64 #checkretval-needs-nonaarch
	else
		echo "cannot install ffmpeg"; exit 1
	fi
	if [ -z "$(command -v ffmpeg)" ]; then
		echo "ffmpeg-failed"; exit 1
	else
		PKGOK="${PKGOK} ffmpeg"
	fi



