


if [ -f /bin/luci-sshon.sh ]; then
    sh /bin/luci-sshon.sh start
fi
#sh /bin/luci-sshon.sh start &
###maybe curl >null to init background img



