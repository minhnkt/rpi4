# Copyright (C) 2013 OpenWrt.org



#20210215 ./build_dir/target-aarch64_cortex-a72_musl/root.orig-bcm27xx/lib/functions/leds.sh










get_dt_led_path() {


    #NOTUSED
    #local FN="get_dt_led_path"
    #echo "$FN-dbg> ${*}" >/dev/console; sleep 2
    #echo "$FN-dbg> ${*}" >/tmp/$FN.out; sleep 2



    local ledpath
	local basepath="/proc/device-tree"
	local nodepath="$basepath/aliases/led-$1"

	[ -f "$nodepath" ] && ledpath=$(cat "$nodepath")
	[ -n "$ledpath" ] && ledpath="$basepath$ledpath"

	echo "$ledpath"



}




get_dt_led() {


    #NOTUSED
    #local FN="get_dt_led"
    #echo "$FN-dbg> ${*}" >/dev/console; sleep 2
    #echo "$FN-dbg> ${*}" >/tmp/$FN.out; sleep 2




    local label
	local ledpath=$(get_dt_led_path $1)

	[ -n "$ledpath" ] && \
		label=$(cat "$ledpath/label" 2>/dev/null) || \
		label=$(cat "$ledpath/chan-name" 2>/dev/null) || \
		label=$(basename "$ledpath")

	echo "$label"


}













led_set_attr() {

    #MODDED WRITE ERROR [ -f "/sys/class/leds/$1/$2" ] && echo "$3" > "/sys/class/leds/$1/$2"
	[ -f "/sys/class/leds/$1/$2" ] && echo -n "$3" > "/sys/class/leds/$1/$2"

}












led_timer() {
	led_set_attr $1 "trigger" "timer"
	led_set_attr $1 "delay_on" "$2"
	led_set_attr $1 "delay_off" "$3"
}










led_on() {
	led_set_attr $1 "trigger" "none"
	led_set_attr $1 "brightness" 255
}









led_off() {
	led_set_attr $1 "trigger" "none"
	led_set_attr $1 "brightness" 0
}






status_led_restore_trigger() {
	local trigger
	local ledpath=$(get_dt_led_path $1)

	[ -n "$ledpath" ] && \
		trigger=$(cat "$ledpath/linux,default-trigger" 2>/dev/null)

	[ -n "$trigger" ] && \
		led_set_attr "$(get_dt_led $1)" "trigger" "$trigger"
}










status_led_set_timer() {
	led_timer $status_led "$1" "$2"
	[ -n "$status_led2" ] && led_timer $status_led2 "$1" "$2"
}








status_led_set_heartbeat() {
	led_set_attr $status_led "trigger" "heartbeat"
}



status_led_on() {
	led_on $status_led
	[ -n "$status_led2" ] && led_on $status_led2
}









status_led_off() {
	led_off $status_led
	[ -n "$status_led2" ] && led_off $status_led2
}




status_led_blink_slow() {
	led_timer $status_led 1000 1000



	#MODNEWHERE
	#[ -n "$status_led2" ] && led_timer $status_led2 1000 1000


}










status_led_blink_fast() {
	led_timer $status_led 100 100



	#MODNEWHERE
	#[ -n "$status_led2" ] && led_timer $status_led 100 100
}










status_led_blink_preinit() {
	led_timer $status_led 100 100

	#MODNEWHERE
	#[ -n "$status_led2" ] && led_timer $status_led 100 100
}










status_led_blink_failsafe() {
	led_timer $status_led 50 50
	#MODNEWHERE
	#[ -n "$status_led2" ] && led_timer $status_led 50 50
}






status_led_blink_preinit_regular() {
	led_timer $status_led 200 200
	#MODNEWHERE
	#[ -n "$status_led2" ] && led_timer $status_led 200 200
}













################################################ ADDITIONS

led_timer_alt() {

    #local FN="led_timer_alt"

	#echo "$FN-1> led_set_attr $1 \"trigger\" \"timer\"" > /dev/console
	led_set_attr $1 "trigger" "timer"

    #echo "$FN-2> led_set_attr $1 \"delay_on\" \"$2\"" > /dev/console
	led_set_attr $1 "delay_on" "$2"

    #echo "$FN-3> led_set_attr $1 \"delay_off\" \"$3\"" > /dev/console
	led_set_attr $1 "delay_off" "$3"
}














status_led_blink_initialize() { #@ done? before rc.local


	###########################################################################################||@/etc/diag.sh-properglobal
	################&& different print ###status_led="ledN" #default led1
    #eval `grep '^RPI4_STATUSLED=' /root/wrt.ini 2>/dev/null`
    #if [ ! -z "$RPI4_STATUSLED" ]; then
    #    status_led="$RPI4_STATUSLED"
    #fi





	#NOTE: hardcoded led1 > status_led2@diag.sh




    case "$1" in
        phase1)
            led_timer_alt $status_led 3523 723
            #HACKWORKAROUNDINCASEOFRPI4_STATUSLED
			led_timer led1 3523 723
        ;;
        phase2)
            led_timer_alt $status_led 2723 523
            #HACKWORKAROUNDINCASEOFRPI4_STATUSLED
            led_timer led1 2723 523
        ;;
        upgrade)
            led_timer_alt $status_led 27 523
            led_timer led1 27 523
        ;;


		"done")
			led_on $status_led
			led_on led1
        ;;
		#status_led_on() {
		#	led_on $status_led
		# [ -n "$status_led2" ] && led_on $status_led2
		#}


	esac

}









#SLOWERBLINKOFFlessannoying #led_timer_alt $status_led 3523 723 #2.0/0.5
#SLOWBLINKOFF led_timer_alt $status_led 1723 323
#SUSTinPAUDEoff v2 led_timer_alt $status_led 1723 323
#SUSTonPAUSEoff led_timer_alt $status_led 2323 323
#BLIPPING OFF led_timer_alt $status_led 23 323
#NOPETESTAGAIN  RAPID led_timer_alt $status_led 330 30


#status_led_blink_slow() {              led_timer $status_led 1000 1000
#status_led_blink_fast() {              led_timer $status_led 100 100
#status_led_blink_preinit() {           led_timer $status_led 100 100
#status_led_blink_failsafe() {          led_timer $status_led 50 50
#status_led_blink_preinit_regular() {   led_timer $status_led 200 200




#@@@ upgrade/X flashing pattern (+assoc inc)
#/lib/upgrade/common.sh:indicate_upgrade() {
#/lib/upgrade/stage2:indicate_upgrade


#grep OF_NAME /sys/devices/platform/leds/leds/led*/uevent
#/sys/devices/platform/leds/leds/led0/uevent:OF_NAME=act
#/sys/devices/platform/leds/leds/led1/uevent:OF_NAME=pwr
#/sys/devices/platform/leds/leds/led18/uevent:OF_NAME=power
#/sys/devices/platform/leds/leds/led23/uevent:OF_NAME=fact
#/sys/devices/platform/leds/leds/led24/uevent:OF_NAME=fpwr


#NOPARAMS #local FN="status_led_blink_initialize"; echo "$FN-dbg-slp2> ${*}" >/dev/console; sleep 2
#NOPARAMS #local FN="status_led_blink_initialize"; echo "$FN-dbg-slp2> ${*}" >/dev/console; sleep 2
#set > /tmp/$FN.SET #status_led=led1
#ZERO echo "$(cat /proc/$PPID/cmdline)" >> /tmp/$FN.CMD
#ZERO echo "$(cat /proc/$$/cmdline)" >> /tmp/$FN.CMD













#    eval `grep '^RPI4_STATUSLED=' /root/wrt.ini 2>/dev/null`
#    if [ ! -z "$RPI4_STATUSLED" ]; then #&& different print ###status_led="ledN" #default led1
#        status_led="$RPI4_STATUSLED"
#    fi



