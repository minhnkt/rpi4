#!/bin/sh
#####################################3#VSTAMP: ABC232 #MODFORloopdev@cpmethod-v1

################################## BOTTOM # copied from x86's platform.sh
#. /lib/functions.sh
#REQUIRE_IMAGE_METADATA=1























ech() {
	if [ -z "$SDEBUG" ]; then return 0; fi
	local dslp=2
	echo "D> ${*}"
	sleep $dslp

}



















################################################################################################################

#GOLLY

dumppartuuids() {

	rm /tmp/diskfind 2>/dev/null
	fdisk -l | tr -s '\t' ' ' | grep '^/dev/sd' | cut -d' ' -f1 | sed 's![1-9]!!g' | uniq >> /tmp/diskfind
	fdisk -l | tr -s '\t' ' ' | grep '^/dev/mmc' | cut -d' ' -f1 | sed 's!p[0-9]$!!g' | uniq >> /tmp/diskfind
	for dISK in $(cat /tmp/diskfind); do
		partuuid=$(fdisk -l "$dISK" | sed -n 's/Disk identifier: 0x\([^ ]*\)/\1/p')
		echo "$dISK $partuuid"
	done

}

#@@@PARTUUID FIXES NEEDED


################################################################################################################















































cleanrootfsdirs() {


	#@@@ /restorefile @ sysupgrade.tgz || z



	local rootfsmnt="$1"

	#NOTWORKIN>var->tmp-L    run init boot; do
	for fold in etc root lib bin overlay sbin usr proc sys tmp mnt dev www rom var run init; do
		if [ -e ${rootfsmnt}/$fold ]; then
			[ ! -z "$SDEBUG" ] && echo -n " /${fold}"
			rm -rf ${rootfsmnt}/${fold}
		else
			[ ! -z "$SDEBUG" ] && echo -n " -/${fold}";
		fi; [ ! -z "$SDEBUG" ] && sleep 1
	done; [ ! -z "$SDEBUG" ] && echo ""
	#echo "######################### postclean check"; sleep 2; ls -la $rootfsmnt/; sleep 5


}










rpi4_cleanup() {
	: # errexit umount everything
}

















rpi4_flash_os() {



	#SDEBUG=1

	local IMAGE="${1}"
	local partdev="${2}"
	local bootospath="${3}"
	local rootfsdev="${4}"
	local bootdir="$(basename ${bootospath})"



	echo "bootdir: $bootdir"



	case "$partdev" in #bootPART="/dev/mmcblk0p1"
	/dev/mmcblk0)
		bootPART="/dev/mmcblk0p1"
	;;
	/dev/sda)
		bootPART="/dev/sda1"
	;;
	*)
		echo "do_flash: unsupported partdev: $partdev"
		sleep 7
		return 1
	;;
	esac








	MEMFREE=$(free | grep '^Mem' | tr -s '\t' ' ' | cut -d' ' -f4)
	if [ "$MEMFREE" -lt 16000 ]; then
		echo "memory too small: $MEMFREE"
		sleep 3
		return 1
	fi


	#echo "################ shm pre"; free | grep 'Mem'; mount | grep ' /tmp '; sleep 2
	ech "mount -o remount,size=1750M /dev/shm /tmp/"
	mount -o remount,size=1750M /dev/shm /tmp/

	#echo "################ shm now"; free | grep 'Mem'; mount | grep ' /tmp '; sleep 2


	ech "\$@: $@"
    	#sleep 5





        mkdir -p /mnt/bootPART /mnt/rootPART

	echo "mount bootpart: $bootPART"
	ech "mount -t vfat -o rw,noatime $bootPART /mnt/bootPART"
	mount -t vfat -o rw,noatime $bootPART /mnt/bootPART
	#@@@||
	#sleep 2



	SDEBUG=1
	fsckadisk "ext4" "$rootfsdev"
	SDEBUG=
	#SDEBUG=1




	echo "mount rootfspart: $rootfsdev"
	ech "mount $rootfsdev /mnt/rootPART"
	mount $rootfsdev /mnt/rootPART
	#@@@||

	if [ ! -r /mnt/bootPART/kernel8.img ]; then
		echo "/mnt/bootPART/kernel8.img [prev-nope]"
		return 1
	fi

	#WASEXIT->mayaswellfixit
	if ! grep -q "$rootfsdev" /mnt/bootPART/$bootdir/cmdline.txt; then
		echo "/mnt/bootPART/$bootdir/cmdline.txt [set $rootfsdev]"
		sed -i "s!root=/dev/mmcblk0p2!root=$rootfsdev!g" /mnt/bootPART/$bootdir/cmdline.txt
		sleep 5
	fi
	if ! grep -q "$rootfsdev" /mnt/bootPART/$bootdir/cmdline.txt; then
		echo "/mnt/bootPART/$bootdir/cmdline.txt [no $rootfsdev]"
		sleep 10
		return 1
	fi



	echo "Checking image $1"
	ech "zcat \"$1\" > /tmp/sysup.img"
	#return 1
	zcat "$1" > /tmp/sysup.img
	ech "$(du -ch /tmp/sysup.img | tr -s '\t' ' ' | head -n 1)"
	#return 1

	LOOPDEV=$(losetup -Pf --show /tmp/sysup.img)

	#ech "ls /dev | grep \"${LOOPDEV}*\""
       	ls /dev | grep "${LOOPDEV}" #mount /dev/loop0pX > /mntX #mount -t vfat -o noatime /dev/loop0p1 /mnt/p1





	mkdir -p /mnt/p1 /mnt/p2
        mount -t vfat -o rw,noatime /dev/loop0p1 /mnt/p1
        mount /dev/loop0p2 /mnt/p2


	#mount | grep loop
	#sleep 5

	echo "Copy bootpart: $bootdir/kernel8.img"
	ech "cp /mnt/p1/kernel8.img /mnt/bootPART/$bootdir/kernel8.img"
	cp /mnt/p1/kernel8.img /mnt/bootPART/$bootdir/kernel8.img
	#sleep 2




	if ! grep -q '^isvalid=1' /mnt/bootPART/$bootdir/os.ini 2>/dev/null; then
		ech "echo isvalid=1 > $bootdir/os.ini"
		echo 'isvalid=1' > /mnt/bootPART/$bootdir/os.ini
	fi


	echo "Scrubbing rootfs"
	cleanrootfsdirs "/mnt/rootPART"
	#sleep 2




	echo "Copy rootfs $rootfsdev"
	ech "cp -arf /mnt/p2/. /mnt/rootPART/"
	cp -arf /mnt/p2/. /mnt/rootPART/
	sync
	#sleep 5
    	#return 1


	#echo "lice"; sleep 2; set -x


	if [ ! -z "$UPGRADE_BACKUP" ] && [ ! -z "$BACKUP_FILE" ]; then
		echo "Saving config to /mnt/rootPART"
		cp -v "$UPGRADE_BACKUP" "/mnt/rootPART/$BACKUP_FILE"
	else
		echo "Saving config to /mnt/rootPART [wip-todo-support-nosave]"


		#MAJORINTERMITTENTBUG sysupgrade -k -b "/mnt/rootPART/sysupgrade.tgz" 2>/dev/null >/dev/null
		#NOPE > synced > /lib/upgrade/* do_stage2NOPE stage2PROBABLY rpi4.shPROBABLY->IS... didnotcommentoutlinine



		rm /mnt/rootPART/sysupgrade.tgz 2>/dev/null
		sysupgrade -k -b /mnt/rootPART/sysupgrade.tgz
		sync
		#mount | grep rootPART
		#ls -la /mnt/rootPART/
		#df -h

	fi




	#echo "rice"; sleep 2







	ech "################################################## prefix toggle 0"
	ech "$(cat /mnt/bootPART/config.txt | grep '^os_prefix')"

	ech "################################################## prefix toggle 1"
	sed -i 's!^os_prefix=!#os_prefix=!g' /mnt/bootPART/config.txt
	ech "$(cat /mnt/bootPART/config.txt | grep '^os_prefix')"


	ech "################################################## prefix toggle 2"
	sed -i "s!^#os_prefix=${bootdir}!os_prefix=${bootdir}!g" /mnt/bootPART/config.txt
	ech "$(cat /mnt/bootPART/config.txt | grep '^os_prefix')"








	#echo "nice"; sleep 2

	echo "sync"
	sync





	echo "umount"
	umount /mnt/bootPART
	umount /mnt/rootPART
	umount /mnt/p1
	umount /mnt/p2
	#sleep 2


	losetup -D #-d ${LOOPDEV}
	#sleep 2



	ech "rm /tmp/sysup.img"
	#sleep 2
	rm /tmp/sysup.img






	ech "checkumounted"
	mount | grep '/mnt'
	#sleep 3




	ech "mount -o remount,size=950M /dev/shm /tmp/"
	mount -o remount,size=950M /dev/shm /tmp/
	#sleep 2

	#if ! return 1
	return 0
	return 1







PARTITION_TABLE=$(parted -m "$ROOT_DEV" unit s print | tr -d 's')
LAST_PART_NUM=$(echo "$PARTITION_TABLE" | tail -n 1 | cut -d ":" -f 1)
 echo "LAST_PART_NUM: $LAST_PART_NUM"



    #parted -s -m /dev/mmcblk0 print
#[root@dca632 /usbstick 44°]# parted -s -m /dev/mmcblk0 print
#BYT;
#/dev/mmcblk0:32.0GB:sd/mmc:512:512:msdos:SD EB1QT:;
#1:4194kB:407MB:403MB:fat16::boot, lba;
#2:411MB:1418MB:1007MB:ext2::;
#3:1418MB:2491MB:1074MB:ext4::;
#4:2491MB:3565MB:1074MB:ext4::;

  #ROOT_PART_LINE=$(echo "$PARTITION_TABLE" | grep -e "^${ROOT_PART_NUM}:")
  #echo "ROOT_PART_LINE: $ROOT_PART_LINE"
  #ROOT_PART_START=$(echo "$ROOT_PART_LINE" | cut -d ":" -f 2)
  #echo "ROOT_PART_START: $ROOT_PART_START"
  #ROOT_PART_END=$(echo "$ROOT_PART_LINE" | cut -d ":" -f 3)
  #echo "ROOT_PART_END: $ROOT_PART_END"

  #LAST_PART_LINE=$(echo "$PARTITION_TABLE" | tail -n 1)
  #echo "LAST_PART_LINE: $ROOT_PART_LINE"
  #LAST_PART_START=$(echo "$LAST_PART_LINE" | cut -d ":" -f 2)
  #echo "LAST_PART_START: $LAST_PART_START"
  #LAST_PART_END=$(echo "$LAST_PART_LINE" | cut -d ":" -f 3)
  #echo "LAST_PART_END: $LAST_PART_END"

#3:1418MB:2491MB:1074MB:ext4::;
#4:2491MB:3565MB:1074MB:ext4::;

#parted -a optimal ${OUTDEV} --script mkpart primary ext4 500MB 3000MB
#parted -a optimal ${OUTDEV} --script mkpart primary ext4 3000MB 100%
#parted -a optimal ${OUTDEV} --script mkpart primary ext4 3000MB 100%


  if [ "$LAST_PART_NUM" -eq 2 ]; then

      roughSDmbtotal=$(($(echo $(cat /sys/block/mmcblk0/size)) / 2000))

  #LAST_PART_END=$(echo "$LAST_PART_LINE" | cut -d ":" -f 3)
    echo "parted -s addpart"
    #parted -a optimal ${OUTDEV} --script mkpart primary ext4 ${LAST_PART_END} 3000MB


    fi

######################################################################
    return 1
	sync
#	if [ "$UPGRADE_OPT_SAVE_PARTITIONS" = "1" ]; then
#		get_partitions "/dev/$diskdev" bootdisk
		#extract the boot sector from the image
#		get_image "$@" | dd of=/tmp/image.bs count=1 bs=512b


}


#echo "rpi4_flash_os \"/dev/mmcblk0\" \"$bootdir\" \"$rootfsout\""
#sed -i "s!root=/dev/mmcblk0p2!root=$rootfspart!g" $bootpart/cmdline.txt





























platform_copy_configalt() {


	local partdev osnum #vanilla

	if export_partdevice partdev 1; then

		mkdir -p /boot
		[ -f /boot/kernel.img ] || mount -t vfat -o rw,noatime "/dev/$partdev" /boot

		#cp -af "$UPGRADE_BACKUP" "/boot/$BACKUP_FILE"
		#tar -C / -zxvf "$UPGRADE_BACKUP" boot/cmdline.txt boot/config.txt


		#@@@??? os2???
		cp -af "$UPGRADE_BACKUP" "/boot/${BACKUP_FILE}_os2"
		tar -C / -zxvf "$UPGRADE_BACKUP" boot/$osnum/cmdline.txt boot/$osnum/config.txt

		#sed os_prefix
        	sync
		umount /boot

	fi


}





























fsckadisk() { #1 fstype #2 /dev/diskNUM

	#command -v fsck.$1 || #check for fsck.fat etc.

	local FN="fsckadisk"
	ech "fsck.$1@$2 [run]"

	case "$1" in
		fat) ech "$(fsck.fat -y $2)"; ;;
		ext4)
       	    		fsck.ext4 -n $2 &>/dev/null; retval=$?
			if [ "$retval" -ne 0 ]; then
                		ech "fsck@$2 [fsck-repair]"
				ech "$(fsck.ext4 -y $2 &>/dev/null)" #echz "retval: $?"
            		else
                		ech "fsck.$1 @$2 [fsck-clean]"
            		fi
        	;;
        	*) ech "$FN> unknown fs: $1"; ;;
	esac

}



































rpi4_do_upgrade() {

	#we are here if .multiwascreated assume multiboot but handle sdX 'ISOLATED DISK' (ie: same stuff just alt DEV)
	#zcat losetup




	local slp=2
	local FN="rpi4_do_upgrade"



	local IMAGE="${1}"
	local SAVE_CONFIG="${2}"





	echo "$FN> board_name: $board_name"  #"to /dev/$partdev..."
	sleep ${slp:-1}
	# echo "GOAT"


	case "$board_name" in
		#raspberrypi,4-model-b)
		raspberrypi,4-model-b|raspberrypi,400|raspberrypi,4-compute-module)
			:
		;;
    		*) echo "unknown board_name: $board_name"; return 1; ;; #FORCE?
	esac  #sleep ${slp:-1}



	ech "pwd: $(pwd)"; #sleep 3


	#if [ ! -z "$RAM_ROOT" ]; then #RAM_ROOT=/tmp/root
	if [ ! -z "$RAM_ROOT" ] && [ -d "$RAM_ROOT" ]; then #RAM_ROOT=/tmp/root
		ech "RAM_ROOT: $RAM_ROOT"
		sleep ${slp:-1}
	fi

	#echo "LIMUR"
	#sleep ${slp:-2}
	#return 1


	###########@@@platform_do_upgrade
	if export_bootdevice; then

		if export_partdevice diskdev 0; then
            		echo "$FN> diskdev (upgradedevice): $diskdev"
        	else
			echo "$FN> Unable to determine upgrade device"
        	fi
    	else
        	echo "$FN> Unabletodetermineupgradedevice@export_bootdevice"
    	fi





	local magic="$(dd if="$1" bs=2 count=1 2>/dev/null | hexdump -n 2 -e '1/1 "%02x"')"
	case "$magic" in
		1f8b) echo "$FN> image:$1 is:gz(tar)";;
		425a) echo "$FN> image:$1 is:bzcat";;
		*) cmd="cat";;
	esac
	sleep ${slp:-1}



	#isbootpart sdX?||non mmcblk0p1?
        #are we vanilla and do we have free space? > PARTSETUP
        ################@@@ this function now only called if osprefix 1 or 2 is preset############
        #if ! grep -q '^os_prefix=' /boot/config.txt; then
            #vanilla=1
        #    CONFIGNOPREFIX=1
        #    currentos="baseos"
        #else
        #    currentos=$(grep '^os_prefix=' /boot/config.txt | cut -d'=' -f1 | sed "s!'!!" | sed 's!"!!')
        #fi

        #currentos=$(grep '^os_prefix=' /boot/config.txt | cut -d'=' -f1 | sed "s!'!!" | sed 's!"!!')







	#nextos ignored for now just toggle
        case "$(cat /proc/cmdline)" in

            *"os_prefix=os1"*) #vanilla=1 #CONFIGNOPREFIX=1 #currentos="baseos"
                bootdir="/boot/os2"
                kernelout="/boot/os2/kernel8.img"
                rootfsout="/dev/mmcblk0p4"
            ;;
            *"os_prefix=os2"*)
                bootdir="/boot/os1"
                kernelout="/boot/os1/kernel8.img"
                rootfsout="/dev/mmcblk0p3"
            ;;
            *)
		echo "unable to determine prefix ( tail -c23 /proc/cmdline )"
		tail -c23 /proc/cmdline
		sleep ${slp:-1}
		sleep 6
		return 1
            ;;
        esac




        echo "####################################################"
        echo "  bootdir: $bootdir"
        echo "kernelout: $kernelout"
       	echo "rootfsout: $rootfsout"
	sleep ${slp:-1}
	#sleep ${slp:-1}
	#sleep ${slp:-1}


    	#DOWEHAVEALLTHETOOLS
        ech "rpi4_flash_os \"/dev/mmcblk0\" \"$bootdir\" \"$rootfsout\" DUMMYCOMMAND-SKIP"


	#ech "rpi4_flash_os \"/dev/mmcblk0\" \"$bootdir\" \"$rootfsout\""
       	#rpi4_flash_os "$IMAGE" "/dev/mmcblk0" "$bootdir" "$rootfsout"
        sleep 2


	######################################
        #echo "$(free | grep 'Mem')"; free | grep 'Mem'; sleep 7

        #maybe mount boot meh in flash_os
        echo "[done]"
        return 0
        exit 1

}


















################################# common.sh imports/info
#default_do@common.sh-bottom


exportpartdeviceng() { #modded-common.sh real common.sh is ../

	local var="$1" offset="$2"
	local uevent line MAJOR MINOR DEVNAME DEVTYPE

	for uevent in /sys/class/block/*/uevent; do
		while read line; do
			export -n "$line"
		done < "$uevent"
		if [ $BOOTDEV_MAJOR = $MAJOR -a $(($BOOTDEV_MINOR + $offset)) = $MINOR -a -b "/dev/$DEVNAME" ]; then
			export "$var=$DEVNAME"
			return 0
		fi
	done

	return 1

}

























######################################3 NEEDED IF CALLING DIRECT
. /lib/functions.sh
######################################3 NEEDED IF CALLING DIRECT
#REQUIRE_IMAGE_METADATA=1
















platform_copy_confignice() {


	local FN="platform_copy_confignice"

    #!@i@
	#!@i@>@@@>platform.sh type platform_copy_config_alt && do and return 0
    #!@i@




	local partdev

	if export_partdevice partdev 1; then


		[ -n "$DEBUG" ] && vplat "$FN> partdev: /dev/$partdev"



		mkdir -p /boot
		[ -f /boot/kernel.img ] || mount -t vfat -o rw,noatime "/dev/$partdev" /boot


        #echo "$FN-dbg> \"$UPGRADE_BACKUP\" -> \"/boot/$BACKUP_FILE\"" > /dev/console; sleep 1
		cp -af "$UPGRADE_BACKUP" "/boot/$BACKUP_FILE"



	        if [ -f /tmp/root/boot/config.txt ] && [ -f /tmp/root/boot/cmdline.txt ]; then
        	    echo "$FN> using raw config.txt&cmdline.txt" > /dev/console
            		cp -af /tmp/root/boot/cmdline.txt /boot/
            		cp -af /tmp/root/boot/config.txt /boot/

            else
                    #echo "$FN> workaround @ true" > /dev/console
            		echo "$FN> using cmdline.txt+config.txt from tar.gz $UPGRADE_BACKUP" > /dev/console
		            #echo "tar -C / -zxvf \"$UPGRADE_BACKUP\" boot/cmdline.txt boot/config.txt" > /dev/console; sleep 1
            		tar -C / -zxvf "$UPGRADE_BACKUP" boot/cmdline.txt boot/config.txt || true
        	fi




            if grep -q 'PARTUUID' boot/cmdline.txt; then
            		#DBG echo "$FN> cmdline.txt PARTUUIDfixup-dbg-copycheck" > /dev/console
            		echo "$FN> cmdline.txt[isPARTUUID] $(cat /boot/cmdline.txt)" > /dev/console
            fi #@@@ PARTUUID fixup if needed -> best handled after || also at dd part2



       		if [ -d /tmp/root/boot/overlays ]; then
				for CoV in $(ls -1 /tmp/root/boot/overlays/); do
					v "copy_overlay:$CoV" ### echo "$FN> copy_overlay:$CoV"
				done
				cp -af /tmp/root/boot/overlays/* /boot/overlays/ 2>/dev/console
	    	else
                v "$FN> copy_overlay: /tmp/root/boot/overlays/ [none]"
                ### echo "$FN> copy_overlay: /tmp/root/boot/overlays/ [none]" > /dev/console
		    fi







        ################################################################## NOTE EXTRACT FROM BACKUP(diff)VERSION UNTESTED
        ###################################################################### isdirect@config.txt@/tmp/rootsamplebelow
        #NOTE ABOVE IS ALL BOOT DO WE NEED TO MOUNT rootfsNEWforthis OR ALREADY HANDLED at PREINIT!!!!!!!!!!!!!!!!!!!
        #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        ##############################################################################################################
        #FORABOVEinBACKUPthenDIFF tar -C / -zxvf "$UPGRADE_BACKUP" boot/cmdline.txt boot/config.txt || true
        #???????? FORABOVEinBACKUPthenDIFF tar -C /tmp/root -zxvf "$UPGRADE_BACKUP" etc/inittab || true
        #if [ -f /tmp/root/etc/inittab ]; then #NOTE /tmp/root VERSION NOT YET USED
        #    echo "$FN> copy inittab to rootpart from /tmp/root/etc/inittab" > /dev/console
        #    #cp -af /tmp/root/etc/inittab /rootfs/etc/
	    #else
        #    echo "$FN> copy inittab to rootpart [nope@/tmp/root/etc/inittab]" > /dev/console
	    #fi
        #############################################################################################################



		sync
		umount /boot
	fi







        #!!! TECHABOVE PREUMOUNT !!!
        #!!! TECHABOVE PREUMOUNT !!!
        #!!! TECHABOVE PREUMOUNT !!!


        ###############NOTE see above... as on rootfs handled by preinit but leave this for extra /tmp/root check sample
        #if [ -f /tmp/root/etc/inittab ]; then #NOTE /tmp/root VERSION NOT YET USED
        #    echo "$FN> copy inittab to rootpart from /tmp/root/etc/inittab" > /dev/console
            ##########FORABOVEinBACKUPthenDIFF tar -C / -zxvf "$UPGRADE_BACKUP" boot/cmdline.txt boot/config.txt || true
            ###########cp -af /tmp/root/etc/inittab /rootfs/etc/
	    #else
        #    echo "$FN> copy inittab to rootpart [nope@/tmp/root/etc/inittab]" > /dev/console
	    #fi




        #local DEBUG=1
		#echo "$FN> DEBUG local 1 for a while to console" > /dev/console && sleep 1
        if [ -f /tmp/root/tmp/.upgradeopts ]; then
		    #echo "$FN> /tmp/root/tmp/.upgradeopts [ok]" > /dev/console && sleep 1
    		[ -n "$DEBUG" ] && echo "/tmp/root/tmp/.upgradeopts [ok]" > /dev/console
	    	[ -n "$DEBUG" ] && echo "$(cat /tmp/root/tmp/.upgradeopts)" > /dev/console
	    	[ -n "$DEBUG" ] && sleep 5
	    else
		    #[ -n "$DEBUG" ] && echo "/tmp/root/tmp/.upgradeopts [nope]" > /dev/console && sleep 1

            : #echo "$FN-dbg> /tmp/root/tmp/.upgradeopts [nope]" > /dev/console && sleep 1
	    fi


        #!!! TECHABOVE PREUMOUNT !!!
        #!!! TECHABOVE PREUMOUNT !!!
        #!!! TECHABOVE PREUMOUNT !!!

}




#echo "$FN> copy inittab to rootpart tba@defineROOTDEV" > /dev/console

#find / | grep 'config.txt$' > /dev/console
#find / | grep 'cmdline.txt$' > /dev/console
##################################################
#/tmp/root/boot/config.txt
#/boot/distroconfig.txt
#/tmp/root/boot/config.txt
#/boot/cmdline.txt
##################################################







#DEBUG=1


WNAME="platform.sh-rpi4.sh" #2021 notplatform


LLL=$(date +%Y%m%d%H%M) ############################ RAMFS_COPY_BIN RAMFS_COPY_BIN="${RAMFS_COPY_BIN} /bin/date"


vplat() {

	#[ -n "$DEBUG" ] && echo "${LLL}-${WNAME}>>> ${1}" > /dev/console
	echo "${WNAME}> ${1}" > /dev/console
}






addcopydatarpiboot() {

	local FN="addcopydatarpiboot"

	local xOVERLAY=
	local oNAME=


	if [ -f /tmp/.upgradeopts ]; then
		[ -n "$DEBUG" ] && vplat "$FN> /tmp/.upgradeopts"
		[ -n "$DEBUG" ] && vplat "$FN> $(cat /tmp/.upgradeopts)"
	fi


	while read xOVERLAY; do

        oNAME="/boot/overlays/$xOVERLAY.dtbo"

		if [ ! -f "$oNAME" ]; then
			vplat "$FN> dtoverlay: $oNAME [nofile]"
		else
			vplat "$FN> dtoverlay: $oNAME [addto-copydata]"
			RAMFS_COPY_DATA="${RAMFS_COPY_DATA} $oNAME"
		fi
	done <<SSS
$(cat /boot/config.txt  | grep '^dtoverlay' | sed 's!dtoverlay=!!g' | cut -d',' -f1)
SSS


#@@@ source /tmp/.upgradeopts if -z ...!NOTE:stocklogicNOEXIST  #@@@ learndisksetup rpidiscoverdisks



if ! grep -q "^rootfsdev=" /tmp/.upgradeopts 2>/dev/null; then #echo "rootfsdev=$(getrpirootfscmdline)"
	vplat "$FN> rootfsdev add upgradeopts: $(getrpirootfs 'cmdline')"
	echo "rootfsdev=$(getrpirootfs 'cmdline')" >> /tmp/.upgradeopts
else
	vplat "$FN> rootfsdev in upgradeopts: $(cat /tmp/.upgradeopts | grep '^rootfsdev')"
fi


if ! grep -q "^bootfsdev=" /tmp/.upgradeopts 2>/dev/null; then
	vplat "$FN> bootfsdev add upgradeopts: $(getrpibootfs)"
	echo "bootfsdev=$(getrpibootfs)" >> /tmp/.upgradeopts
else
	vplat "$FN> bootfsdev in upgradeopts: $(cat /tmp/.upgradeopts | grep '^bootfsdev')"
fi



#SLICE
if grep -q "^ROOTFSEXPAND" /root/wrt.ini; then
	vplat "$FN> rootfsexpand [on]"
	#double logic for this also at sysupgradefirst was initally here but print easierniceratsysupgrade
	#and partitions changed may miss this?
	if ! grep -q "rootfsexpand" /tmp/.upgradeopts 2>/dev/null; then
		echo "rootfsexpand=1" >> /tmp/.upgradeopts
	fi
fi




if [ -f /tmp/.upgradeopts ]; then
	vplat "$FN> /tmp/.upgradeopts [add]"
	RAMFS_COPY_DATA="${RAMFS_COPY_DATA} /tmp/.upgradeopts"
else
	vplat "$FN> /tmp/.upgradeopts [nope]"
fi



}





getrpibootfs() {

	. /lib/upgrade/common.sh

	if export_bootdevice; then	#BOOTPART=/dev/mmcblk0p1
		if export_partdevice BOOTPART 1; then
       			BOOTPART="/dev/$BOOTPART"
		else
			BOOTPART="/dev/mmcblk0p1"
		fi
	else
		BOOTPART="/dev/mmcblk0p1"
	fi
	echo "$BOOTPART"
}










dumpuuids() { #2021 WIP
#################################################################################################### @@@ismbr||isgpt
(find /dev/sd* 2>/dev/null | sort | uniq; find /dev/mmc* /dev/nvm* 2>/dev/null | sort | uniq) | \
	grep -v '0$' | \
	grep -v '[a-z]$' | while read THIS; do
	THEUUID=$(partx -g -o UUID "$THIS" 2>/dev/null)
	echo "$THIS ${THEUUID:-NONE}"
done
##################################################################################################
}










getrpirootfs() {

	local FN="getrpirootfs" #blkid||partx block info
	local gotrootfs=

	case "${1}" in
		cmdline)
			gotrootfs=$(sed -n 's|^.*root=\(\S\+\)\s.*|\1|p' /boot/cmdline.txt)

			case "$gotrootfs" in #2021 fixup PARTUUID####################
    				"PARTUUID="*)
            			PUUID=$(echo $gotrootfs | sed 's!PARTUUID=!!g' | sed 's!"!!g' | sed "s!'!!g")
            #			#!!!blkid
				if [ ! -z "$(command -v blkid)" ]; then
					gotrootfs=$(blkid | grep "$PUUID" | cut -d':' -f1)
				else #partx
                    gotrootfs=$(dumpuuids | grep "$PUUID" | cut -d' ' -f1) #WARNINGNEVER-TESTED!!!
				fi
			;; #echo "PARTUUIDfixupPOST: $ROOTFSPART" > /dev/console
			esac
        ;;

		mounted)
			gotrootfs=$(block info | grep 'MOUNT="/"' | grep 'TYPE="ext4"' | cut -d':' -f1)
		;;

		validalt) #block info | grep 'MOUNT="/"' | grep 'TYPE="ext4"' | cut -d':' -f1
			if [ -z "${2}" ]; then
				echo "$FN> $1 needs dev as 2" >&2
				return 1
			fi

			gotrootfs=$(block info | grep 'TYPE="ext4"' | grep 'LABEL="rootfs' | grep "${2}" | cut -d':' -f1)
		;;

		*)
			echo "whoops $FN pass1 cmdline||mounted"; return 1
		;;
	esac

	if [ -z "$gotrootfs" ]; then
			echo "whoops $FN $1 notfound" && return 1
	elif echo "$gotrootfs" | grep -q "PARTUUID"; then
			echo "whoops $FN $1 PARTUUID: $gotrootfs" && return 1
	fi

	echo "$gotrootfs"
	return 0

}








getrpirootfspart() {

	local rootfscmdline=$(getrpirootfs 'cmdline')
	local rootfsmounted=$(getrpirootfs 'mounted')

	if [ "$rootfscmdline" != "$rootfsmounted" ]; then
		echo "2> cmdline and mounted differ: c:$rootfscmdline m:$rootfsmounted" >&2
		echo "2> cmdline and mounted differ: c:$rootfscmdline m:$rootfsmounted" > /dev/console
	else
		echo "2> cmdline and mounted equal c:$rootfscmdline m:$rootfsmounted" >&2
		echo "2> cmdline and mounted equal c:$rootfscmdline m:$rootfsmounted" > /dev/console
	fi

	echo "$rootfscmdline"


}





rpidiscoverdisks() {

	:
}


#block info | grep 'MOUNT="/boot"' | wc -l
#block info | grep 'LABEL="boot"' | wc -l
#block info | grep 'LABEL="/rootfs"' | wc -l
#block info | grep 'LABEL="/rootfsalt"' | wc -l

















if [ "$(pwd)" = "/tmp/root" ]; then ISTMP=1; fi
case "$(cat /proc/$PPID/cmdline)" in
	"/sbin/rpcd"*) ISLUCI=1; ;;
esac
case "$0 ${*}" in #2case "$0" in #case "$(cat /proc/$$/cmdline)" in
	*"validate_firmware"*) ISVALIDATE=1; ;;
esac

















case "$(cat /proc/$$/cmdline)" in

	*"/lib/upgrade/stage2"*)
		UPGSTAGE="${UPGSTAGE} stage2"
		ISSTAGE2=1
	;;

	*"/lib/upgrade/do_stage2"*)
		ISDOSTAGE2=1
		if [ ! -z "$ISTMP" ] && grep -q '/sbin/upgraded' /proc/$PPID/cmdline 2>/dev/null; then
			UPGSTAGE="${UPGSTAGE} do_stage2post"
		else
			UPGSTAGE="${UPGSTAGE} do_stage2pre"
		fi

	;;

	*"/sbin/sysupgrade"*)
		ISSYSUPGRADE=1
		UPGSTAGE="${UPGSTAGE} sysupgrade"
		if [ -z "$ISLUCI" ]; then ISUSER=1; fi
	;;


	*"libexec/validate_firmware_image"*) #	if grep -q '/sbin/procd' /proc/$PPID/cmdline 2>/dev/null; then
		UPGSTAGE="${UPGSTAGE} validate"
	;;
esac


#@@@TESTINGTHIS if [ -z "$UPGSTAGE" ] && [ ! -z "$ISVALIDATE" ]; then #if [ ! -z "$DEBUG" ]; then #if [ ! -z "$DEBUG" ]; then
if [ ! -z "$ISVALIDATE" ]; then
	grep -q "firmware.bin" /proc/$PPID/cmdline && UPGSTAGE="${UPSTAGE} validateluci"
	grep -q "img.gz" /proc/$PPID/cmdline && UPGSTAGE="${UPSTAGE} validateuser"
fi


######################################################################################
#if [ -z "$UPGSTAGE" ]; then
#	if grep -q '/sbin/procd' /proc/$PPID/cmdline 2>/dev/null; then
#		if grep -q 'libexec/validate_firmware_image' /proc/$$/cmdline >/dev/null; then
#			UPGSTAGE="valproc"
#		fi
#	fi
#fi
######################################################################################
#if [ ! -z "$ISTMP" ]; then
#	if grep -q '/sbin/upgraded' /proc/$PPID/cmdline 2>/dev/null; then
#		if grep -q '/lib/upgrade/do_stage2' /proc/$$/cmdline 2>/dev/null; then
#			UPGSTAGE="${UPGSTAGE} do_stage2tmpREAL"
#		fi
#	fi
#fi
######################################################################################
#if [ -z "$UPGSTAGE" ] && [ ! -z "$ISVALIDATE" ]; then #if [ ! -z "$DEBUG" ]; then
#	grep -q "firmware.bin" /proc/$PPID/cmdline && UPGSTAGE="validateluci"
#	grep -q "img.gz" /proc/$PPID/cmdline && UPGSTAGE="validateuser"
#fi
######################################################################################

























if [ ! -z "$DEBUG" ] || [ -z "$UPGSTAGE" ]; then #if [ ! -z "$DEBUG" ]; then

	vplat "ppidcmdline: $(cat /proc/$PPID/cmdline)" > /dev/console
	vplat "\$\$cmdline: $(cat /proc/$$/cmdline)" > /dev/console

	vplat "STAGEUNKNOWNorDEBUG UPGSTAGE:$UPGSTAGE ISLUCI:$ISLUCI ISUSER:$ISUSER ISTMP:$ISTMP" > /dev/console

fi






#2021 else #@@@~2021 USE fi^ and NEWCASEBELOW
#2021 else #@@@~2021 USE fi^ and NEWCASEBELOW
#2021 else #@@@~2021 USE fi^ and NEWCASEBELOW









	case "${UPGSTAGE}" in
		*"validate"*)
			: #vplat "DBGVAL: UPGSTAGE:$UPGSTAGE ISLUCI:$ISLUCI ISUSER:$ISUSER ISTMP:$ISTMP" > /dev/console
		;;
        #do_stage2)
            #vplat "UPGSTAGE:$UPGSTAGE ISLUCI:$ISLUCI ISUSER:$ISUSER ISTMP:$ISTMP" > /dev/console
        #;;
        *)
			vplat "UPGSTAGE:$UPGSTAGE ISLUCI:$ISLUCI ISUSER:$ISUSER ISTMP:$ISTMP" > /dev/console
		;;
	esac



#2021 ALWAYS PARSE THIS fi #vplat ">>> UPGSTAGE:$UPGSTAGE ISLUCI:$ISLUCI ISUSER:$ISUSER ISTMP:$ISTMP" > /dev/console
#2021 ALWAYS PARSE THIS fi #vplat ">>> UPGSTAGE:$UPGSTAGE ISLUCI:$ISLUCI ISUSER:$ISUSER ISTMP:$ISTMP" > /dev/console
#2021 ALWAYS PARSE THIS fi #vplat ">>> UPGSTAGE:$UPGSTAGE ISLUCI:$ISLUCI ISUSER:$ISUSER ISTMP:$ISTMP" > /dev/console







################################ 20210377@sysupgrade -T (sysuponline@gitlatest) stage:sysupgrade ISUSER=1
#platform.sh-rpi4.sh> UPGSTAGE: sysupgrade ISLUCI: ISUSER:1 ISTMP:
############### usr-libexec-validate-fw-image json_dump
#{ "tests": { "fwtool_signature": true, "fwtool_device_match": true }, "valid": true, "forceable": true, "allow_backup": true }
#@@@???+zISTMPforsafe if [ "$UPGSTAGE" = "sysupgrade" ] && [ ! -z "$ISUSER" ]; then #if [ ! -z "$DEBUG" ]; then
#&&-zISSTAGE2?
if [ "$UPGSTAGE" = "sysupgrade" ] && [ ! -z "$ISUSER" ] && [ -z "$ISTMP" ]; then #if [ ! -z "$DEBUG" ]; then
	echo "20210377JUSTCHECKING DBGi> probably a manual sysup -T" > /dev/console
fi

















#if [ -z "$ISVALIDATE" ] && [ ! -z "$ISSTAGE2" ] && [ -z "$ISTMP" ]; then
if [ -z "$ISVALIDATE" ] && [ ! -z "$ISSTAGE2" ]; then #NOPE if [ -z "$ISVALIDATE" ] && [ ! -z "$ISSYSUPGRADE" ]; then


	############################## config.txt cmdline.txt largesysup fix @ platform_copy_config

	RAMFS_COPY_BIN="${RAMFS_COPY_BIN} /bin/date" #notworking

	if [ ! -z "$DEBUG" ]; then vplat "RAMFS_COPY_DATA_ORG: $RAMFS_COPY_DATA" > /dev/console; fi
	RAMFS_COPY_DATA="${RAMFS_COPY_DATA} /boot/cmdline.txt /boot/config.txt"
	if [ ! -z "$DEBUG" ]; then vplat "RAMFS_COPY_DATA_TXT: $RAMFS_COPY_DATA" > /dev/console; fi
	addcopydatarpiboot
	if [ ! -z "$DEBUG" ]; then vplat "RAMFS_COPY_DATA-FINAL: $RAMFS_COPY_DATA"; fi
	#exit 0


elif [ ! -z "$ISVALIDATE" ]; then
	[ ! -z "$DEBUG" ] && vplat "RAMFS_COPY_DATA-FINAL: $RAMFS_COPY_DATA SKIPADDVALIDATE"
else
	[ ! -z "$DEBUG" ] && vplat "RAMFS_COPY_DATA-FINAL: $RAMFS_COPY_DATA SKIPADD on tmproot or other"
fi













MOREADDS() {


case "${*}" in ############################################ /sbin/sysupgrade --test /tmp/firmware.bin
	*"--test"*|*" -T"*)
		ISVALIDATE=1
		RCDEBUG=
		RCSLEEP=
	;;
esac






case "${*}" in ################ invoke:method""exec""data":"command"/sbin/sysupgrade""params":["/tmp/firmware.bin"]"env":null
	*"/tmp/firmware.bin"*)
		ISLUCI=1
	;;
esac



}






upgsrcstate() { #rpi4.shminial INLINEPARAMPARSINGOFF() {

case "$0" in
    *"/sbin/sysupgrade"*)
            : #echo "sysup-rpi4.sh-inline SBIN-SYSUPG: $0 ${@}" > /dev/console; sleep 3
    ;;
    *"/usr/libexec/validate_firmware_image"*)
        :   #echo "sysup-rpi4.sh-inline VALIDATEFWIMAGE: $0 ${@}" > /dev/console; sleep 3
    ;;
    *"/lib/upgrade/do_stage2"*)
            : #echo "sysup-rpi4.sh-inline DO_STAGE2: $0 $@" > /dev/console; sleep 3
    ;;
    *"/lib/upgrade/stage2"*)
            : #echo "sysup-rpi4.sh-inline STAGE2: $0 $@" > /dev/console
            #sleep 3
    ;;
    *)
	    :
    ;;

esac


}










###################################################################### 2021
#platform.sh> $$cmdline: /bin/sh./master-autosysup-2021-Zzz-Zzz
#platform.sh> UPGSTAGE: ISLUCI: ISUSER: ISTMP:









#$(cat /boot/config.txt  | grep '^dtoverlay' | sed 's!dtoverlay=!!g' | cut -d',' -f1)

