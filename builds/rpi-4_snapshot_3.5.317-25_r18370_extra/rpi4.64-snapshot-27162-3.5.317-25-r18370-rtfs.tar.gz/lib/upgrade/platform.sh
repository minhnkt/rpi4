#!/bin/sh
#FORCOLOR rootfsexpandFIX1
#somethingsomethingsomething


. /lib/functions.sh

REQUIRE_IMAGE_METADATA=1

# copied from x86's platform.sh





platform_check_image() {

	local diskdev partdev diff

	[ "$#" -gt 1 ] && return 1

	export_bootdevice && export_partdevice diskdev 0 || {
		echo "Unable to determine upgrade device"
		return 1
	}

	get_partitions "/dev/$diskdev" bootdisk





	#extract the boot sector from the image
	##############################################################################
	#ORIGINAL get_image "$@" | dd of=/tmp/image.bs count=1 bs=512b 2>/dev/null
	##############################################################################
	#GETIMAGE NO2NULL #get_image_dd "$1" of="/tmp/image.bs" count=1 bs=512b 2>/dev/null
	##########################echo "newgetimagedd image.bs check_image()"
	#################v "Extract boot sector from the image > /tmp/image.bs count=1 bs=512b"
	#v "Extract boot sector from the image" #get_imageprints_similar
	##############################################################################
	get_image_dd "$1" of="/tmp/image.bs" count=1 bs=512b
	get_partitions /tmp/image.bs image
	############################################################################compare tables
	diff="$(grep -F -x -v -f /tmp/partmap.bootdisk /tmp/partmap.image)"
	#DBG?> v "$diff?"


	#######################IMPORTANTORIGINAL-REENABLEANDREMOVELOWERSECTIONSONNONDBG
	#######################IMPORTANTORIGINAL-REENABLEANDREMOVELOWERSECTIONSONNONDBG
	#######################IMPORTANTORIGINAL-REENABLEANDREMOVELOWERSECTIONSONNONDBG

	#rm -f /tmp/image.bs /tmp/partmap.bootdisk /tmp/partmap.image

	#######################IMPORTANTORIGINAL-REENABLEANDREMOVELOWERSECTIONSONNONDBG
	#######################IMPORTANTORIGINAL-REENABLEANDREMOVELOWERSECTIONSONNONDBG
	#######################IMPORTANTORIGINAL-REENABLEANDREMOVELOWERSECTIONSONNONDBG

	if [ -n "$diff" ]; then
		#ROOTFSEXPAND=1 next upgrade triggers this skips two part write and resize logic
		#this is just notify... find n diff in write section
		#echo "Partition layout has changed. Full image will be written."
		
		
		#THECOMMONONEifENLARGED
		################v "/tmp/image.bs:$(cat /tmp/image.bs)"
		##############tmp/partmap.bootdisk:$(cat /tmp/partmap.bootdisk)"#tmp/partmap.image:$(cat /tmp/partmap.image)"
		###v " disk:$(cat /tmp/partmap.bootdisk | sed ':a;N;$!ba;s/\n/ /g')"
		###v "image:$(cat /tmp/partmap.image | sed ':a;N;$!ba;s/\n/ /g')"
		v " disk:$(cat /tmp/partmap.bootdisk | sed 's|^|>|g' | sed ':a;N;$!ba;s/\n/ /g')"
		v "image:$(cat /tmp/partmap.image | sed 's|^|>|g' | sed ':a;N;$!ba;s/\n/ /g')"



		rm -f /tmp/image.bs /tmp/partmap.bootdisk /tmp/partmap.image


		v "Layout changed writing full image... "
		ask_bool 0 "Abort" && exit 1
		return 0
	



	else ####################################################HACKFORSHOW-REMOVE
		rm -f /tmp/image.bs /tmp/partmap.bootdisk /tmp/partmap.image
	####################################################################-REMOVE


	fi

	return 0;
}

















checkrootfsresize() {


#@if [ -z "${diskdev}" ]; then
#@if [ -z "$WRITEUUID" ]; then


if [ ! -f /tmp/.upgradeopts ]; then
	NORESIZE="${NORESIZE} no:/tmp/.upgradeopts"
else
	eval $(grep 'rootfsexpand=' /tmp/.upgradeopts 2>/dev/null)
	if [ -z "$rootfsexpand" ]; then
		NORESIZE="${NORESIZE} rootfsexpand[off]"
		#@@@multiopts SET resizeMETHOD="expand" or fulldisk
	fi


	

fi #echo "rootfsexpand=1" >> /tmp/.upgradeopts







#@!>weshouldcheckthesealsopreupgradeIFexpandoptset
reqCMDs="parted resize2fs blkid e2fsck tail"
for cCMD in $reqCMDs; do
	if [ -z "$(command -v $cCMD)" ]; then NOCMD="${NOCMD} $cCMD"; fi
done

#if [ -z "$(command -v parted)" ]; then NOCMD="${NOCMD} parted"; fi
#if [ -z "$(command -v resize2fs)" ]; then NOCMD="${NOCMD} resize2fs"; fi
#if [ -z "$(command -v blkid)" ]; then NORESIZE="${NORESIZE} blkid"; fi
#if [ -z "$(command -v e2fsck)" ]; then NORESIZE="${NORESIZE} e2fsck"; fi
#if [ -z "$(command -v tail)" ]; then NORESIZE="${NORESIZE} tail"; fi



if [ ! -z "$NOCMD" ]; then NORESIZE="${NORESIZE} nocmd:$NOCMD"; fi




#Y
#if [ ! -z "$(command -v mkfs.ext4)" ]; then
#	v "mkfs.ext4 [available]"
#else
#	v "mkfs.ext4 [notavailable]"
#fi
#N
#if [ ! -z "$(command -v tr)" ]; then
#	v "tr [available]"
#else
#	v "tr [notavailable]"
#fi
#Y
#if [ ! -z "$(command -v tail)" ]; then
#	v "tail [available]"
#else
#	v "tail [notavailable]"
#fi










diskdevPTCNT=$(blkid  | grep "^/dev/${diskdev}" | wc -l)


if [ "$diskdevPTCNT" -ne "2" ]; then
	#echo "cnt:$diskdev(${diskdevPTCNT})[nomatch]"
	NORESIZE="${NORESIZE} cnt:$diskdev(${diskdevPTCNT})[nomatch]"
else
	#echo "cnt:$diskdev(${diskdevPTCNT})[match]"
	RESIZEOK="${RESIZEOK} cnt:$diskdev(${diskdevPTCNT})"
fi


if ! blkid  | grep "^/dev/${diskdev}" | tail -n1 | grep -q 'LABEL="rootfs"'; then
	#echo "LABEL=rootfs[nomatch]"
	NORESIZE="${NORESIZE} LABEL=rootfs[nomatch]"
else
	#echo "LABEL=rootfs[match]"
	RESIZEOK="${RESIZEOK} LABEL=rootfs"
fi


case "${diskdev}" in
	*mmcblk*)
		DEVp="p"
	;;
	*)
		:
	;;
esac



diskdevR="${diskdev}${DEVp}2"
#echo "rootfs:${diskdevR}[diskdevR]"




rootfsSZ=$(cat /sys/block/${diskdev}/${diskdevR}/size)
if [ "$rootfsSZ" -ne "1966080" ]; then
	#echo "Rsz:${rootfsSZ}[nomatch]" ##############NORESIZE="${NORESIZE} Rsz:${rootfsSZ}[nomatch]"
	NORESIZE="${NORESIZE} sz:${rootfsSZ}[nomatch]"
else
	#echo "Rsz:${rootfsSZ}[match]" ############RESIZEOK="${RESIZEOK} Rsz:${rootfsSZ}[match]"
	RESIZEOK="${RESIZEOK} sz:${rootfsSZ}"
fi



if [ ! -z "$NORESIZE" ]; then
	v "rootfs:${diskdevR} noresize: $NORESIZE [ok:$RESIZEOK]"
	#echo "rootfs:${diskdevR} noresize: $NORESIZE [ok:$RESIZEOK]"
	############@@@possiblyfrom forcedTESTING UPGRADE_OPT_SAVE_PARTITIONS=1 #@@@ bug if we dont resize
	setPTUUID /dev/${diskdev} "$WRITEUUID"
else
	v "rootfs:${diskdevR} resize:$RESIZEOK"
	#########echo "rootfs:${diskdevR} resize: $RESIZEOK"
	#@@@ismounted
	#isrpi4alreadycheckedhere
	dorootfsresize || true
fi
#sleep 2
#exit 0

}






setPTUUID() {
	local inDSK="${1}"
	local PTUUID="${2}"
	if [ "$(getPTUUID "${inDSK}")" = "$PTUUID" ]; then
		v "$PTUUID [ptuuid-ok]" ### echo "$PTUUID [ptuuid-ok]"
	else
		v "$PTUUID [ptuuid-write]" ### echo "$PTUUID [ptuuid-write]"
		(echo p; echo x; echo i; echo 0x${PTUUID}; echo r; echo w) | fdisk "${inDSK}" >/dev/null
	fi
}


getPTUUID() {
	local inDSK="${1}"
	blkid "$inDSK" -s PTUUID -o value
} #blkid /dev/sdc -s PTUUID -o value







dorootfsresize() {


	#local RESIZEdbg=1
	

	if [ -n "$RESIZEdbg" ]; then
		v "parted /dev/${diskdev} resizepart 2 100%" ######## echo "parted /dev/${diskdev} resizepart 2 100%"
		parted /dev/${diskdev} resizepart 2 100%
	else	
		v "resizing rootfs 100%" ################echo "resizing rootfs 100%"
		parted /dev/${diskdev} resizepart 2 100% 1>/dev/null 2>/dev/null
	fi



	[ -n "$RESIZEdbg" ] && getPTUUID /dev/${diskdev}
	setPTUUID /dev/${diskdev} "$WRITEUUID"
	[ -n "$RESIZEdbg" ] && getPTUUID /dev/${diskdev}


	###############################@@@missing e2fsck here or after 100%
	v "resize2fs /dev/${diskdevR}" ########## echo "resize2fs /dev/${diskdevR}"
	if [ -n "$RESIZEdbg" ]; then
		resize2fs /dev/${diskdevR}
	else
		resize2fs /dev/${diskdevR} 1>/dev/null 2>/dev/null
	fi

	[ -n "$RESIZEdbg" ] && echo "sync"
	sync

	[ -n "$RESIZEdbg" ] && getPTUUID /dev/${diskdev}

}



















platform_do_upgrade() {

	local diskdev partdev diff

	export_bootdevice && export_partdevice diskdev 0 || {
		echo "Unable to determine upgrade device"
		return 1
	}

	sync



	#20210717 NOTE THIS DOES NOT REALLY WORK SO COPIED UP THE RESIZE CHECK AFTER WRITE
	#FORCETHISONHERE to see what happens with resize as diff=1 aka we resized prev install
	#at platform_check_image print at sysupgrade means this is a straight write
	#alternative is
	#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	# UPGRADE_OPT_SAVE_PARTITIONS=1 #forcesthisonforabitUNEEDED
	#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

	if [ "$UPGRADE_OPT_SAVE_PARTITIONS" = "1" ]; then
		get_partitions "/dev/$diskdev" bootdisk


		#get_image "$@" | dd of=/tmp/image.bs count=1 bs=512b
		############################################GETIMAGE 2>/dev/null?
		#DBG v "Extract boot sector from image (compare with $diskdev)"
		get_image_dd "$1" of="/tmp/image.bs" count=1 bs=512b

		get_partitions /tmp/image.bs image

		#compare tables
		diff="$(grep -F -x -v -f /tmp/partmap.bootdisk /tmp/partmap.image)"
		


		#20210717 MEHDBGONLY
		#[ -n "$diff" ] && echo "image and disk parts differ: $diff" && sleep 2


	else
		diff=1
	fi




	if [ -n "$diff" ]; then #nb always a diff unless in image is exact as prevparts

		####################################################################3#DBGONLY
		#v "disk:$(cat /tmp/partmap.bootdisk)" ###NOtr? v "disk:$(cat /tmp/partmap.bootdisk | tr -s '\n' ' ')"
		#v "image:$(cat /tmp/partmap.image)"   ###      v "/tmp/partmap.bootdisk:$(cat /tmp/partmap.bootdisk)"


		OLDUUID=$(partx -g -o UUID "/dev/$diskdev" 2>/dev/null | dd bs=1 count=8 2>/dev/null)	
	

		#ORIGINAL get_image "$@" | dd of="/dev/$diskdev" bs=2M conv=fsync
		v "Writing full-image to $diskdev" #v "Writing full-image to $diskdev [<${1}]"
		get_image_dd "$1" of="/dev/$diskdev" bs=2M conv=fsync

        # Separate removal and addtion is necessary; otherwise, partition 1
		# will be missing if it overlaps with the old partition 2
		partx -d - "/dev/$diskdev"
		partx -a - "/dev/$diskdev"





		######### TOOLATE OLDUUID=$(partx -g -o UUID "/dev/$diskdev" 2>/dev/null | dd bs=1 count=8 2>/dev/null)
    	WRITEUUID="$OLDUUID"
		checkrootfsresize || true


		return 0
	fi







    #NOTE didntprint console thing???
    #local DEBUGDISKWRITE=1
    #if [ ! -z "$DEBUGDISKWRITE" ]; then
	#    while read part start size; do
	#	    	echo "DBG Writing image to /dev/$partdev... partition:$part start:$start size:$size"
    #    done < /tmp/partmap.image
    #fi




	#v "disk and image partions match"
	#v "disk:$(cat /tmp/partmap.bootdisk)" ##########3v "/tmp/partmap.bootdisk:$(cat /tmp/partmap.bootdisk)"
	#v "image:$(cat /tmp/partmap.image)" ##########v "/tmp/partmap.image:$(cat /tmp/partmap.image)"





	##########################iterate over each partition from the image and write it to the boot disk
	while read part start size; do
		#echo "partition:$part start:$start size:$size"
		if export_partdevice partdev $part; then

			#ORIGINAL echo "Writing image to /dev/$partdev..."
			echo "Writing image-partition:$part to /dev/$partdev... start:$start size:$size"
			
			
			
			###########################20210717 NEWFORLOWERRESIZE #>>>notusedGETfromsysblock
			### if [ "$part" -eq 2 ]; then ROOTFSinSZ="$size"; fi



		#get_image "$@" 2>/dev/null | dd of="/dev/$partdev" ibs="512" obs=1M skip="$start" count="$size" conv=fsync
		get_image_dd "$1" of="/dev/$partdev" ibs="512" obs=1M skip="$start" count="$size" conv=fsync



        else
			#ORIGINAL echo "Unable to find partition $part device, skipped."
			echo "Unable to find partition $part device, skipped."
	fi
	done < /tmp/partmap.image




	##########################################################################################
	#ORIGINALISWRONG ######################get_image "$@" | dd of="/tmp/faketable" bs=2M conv=fsync 2>/dev/null
	######################################disk is full aka 512b count 1
	###########################get_image "$@" | dd of="/tmp/faketable" bs=512b count=1 2>/dev/null
    ############################v "TEST: $(partx -g -o UUID "$1" | dd bs=1 count=8 2>/dev/null)"
	##########################################################################################
	get_image_dd "$1" of="/tmp/faketable" bs=512b count=1

    NEWUUID=$(partx -g -o UUID "/tmp/faketable" | dd bs=1 count=8 2>/dev/null)
    OLDUUID=$(partx -g -o UUID "/dev/$diskdev" 2>/dev/null | dd bs=1 count=8 2>/dev/null)
	#######################################@@@VALIDATE[0-9][a-z]&&||charnum
	############################################NOTUSED
    OLDUUIDASCII=$(dd if=/dev/$diskdev bs=1 skip=440 count=4 2>/dev/null)
    NEWUUIDASCII=$(dd if=/tmp/faketable bs=1 skip=440 count=4 2>/dev/null)
    #ASCIIUGLY echo "Writep PARTUUID[${OLDUUID}:(${OLDUUIDASCII})] /dev/$diskdev... IMG[${NEWUUID}:(${NEWUUIDASCII})]"

	echo "Writing previous PARTUUID[${OLDUUID}] to /dev/$diskdev... IMG[${NEWUUID}]"
    dd if=/tmp/faketable bs=1 skip=440 count=4 2>/dev/null | dd of="/dev/$diskdev" bs=1 skip=440 count=4 seek=440 conv=fsync 2>/dev/null


    WRITEUUID="$OLDUUID"
	checkrootfsresize || true

}













platform_copy_config() {


	local FN="platform_copy_config"



	if type platform_copy_confignice 2>/dev/null 1>/dev/null; then
        ### echo "$FN> CONSOLE using> platform_copy_confignice include@rpi4.sh" > /dev/console
        echo "$FN> using platform_copy_confignice include@rpi4.sh" > /dev/console
        platform_copy_confignice
		return 0
	fi




	local partdev

	if export_partdevice partdev 1; then

		[ -n "$DEBUG" ] && vplat "$FN> partdev: /dev/$partdev"

		mkdir -p /boot
		[ -f /boot/kernel.img ] || mount -t vfat -o rw,noatime "/dev/$partdev" /boot

		cp -af "$UPGRADE_BACKUP" "/boot/$BACKUP_FILE"

        	echo "$FN> workaround @ true" > /dev/console
        	tar -C / -zxvf "$UPGRADE_BACKUP" boot/cmdline.txt boot/config.txt || true

		sync
		umount /boot
	fi


}











